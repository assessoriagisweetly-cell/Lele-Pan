# Casa Lele Pan

A digital doorway into the world of Lele Pan, a neighborhood bakery in Casa Verde, São Paulo (since 1988).
Vite + React prototype, **Demo-Ready V1**. No backend: everything persists in the browser.

## Run

```bash
npm install
npm run dev      # local dev server
npm run build    # production build
npm run preview  # preview the build
```

## Project structure

| File | What it holds |
|---|---|
| `src/CasaLelePan.jsx` | Main app: Home, Cardápio, product detail, cart/checkout, Círculo, Location, Footer, hash routing, styles |
| `src/Desde1988.jsx` | Desde 1988 experience, memory wall, memory detail (likes/comments/moderation), memory composer, legal pages, their styles |
| `src/memories.js` | Memories data layer: storage, media, and **permission enforcement** |
| `src/main.jsx` | React entry point |

## Customer journeys

1. **Order:** Casa → Saiu do Forno → Product → Adicionar → Sacola → Retirar / Receber → WhatsApp
2. **Círculo:** Casa → Círculo → onboarding (once) → Círculo Home → Seu favorito → Pedidos recentes → Seus mimos → Compartilhar uma memória → Desde 1988
3. **Desde 1988:** story → cultural reference → Memórias da casa → view → like → comment
4. **Visit:** Casa → Localização → Abrir no mapa

## Routes (hash-based)

| Route | View |
|---|---|
| `/` | Home |
| `#/desde-1988` | Desde 1988 (public) |
| `#/privacidade` | Política de Privacidade |
| `#/termos` | Termos de Uso |

Legal links live in the footer, are always visible, and never depend on cookie consent (the app has no consent banner).

## Círculo Lele

- Unlocks after **5 completed orders** (`CIRCULO_ORDERS_REQUIRED`). An order counts when the customer hands off to WhatsApp.
- **Onboarding happens once.** Name, birth date (`DD/MM/AAAA`), phone, address are saved with `onboardingCompleted`. Afterwards, **ENTRAR** goes straight to Círculo Home, including after a refresh.
- Names are normalized: `guedalia` → `Guedalia` (first character only).
- **MINHAS INFORMAÇÕES** edits the profile and never resets onboarding.
- The saved address prefills delivery checkout.

## Memórias (Círculo → Desde 1988)

- Members share **one photo or one video** per memory, with a caption and optional date/context.
- Everyone can view, like, and comment on memories, and like comments.
- Moderation: report a post or comment; edit or delete my own post; delete my own comment. Three reports hide a post behind "Conteúdo em análise".
- **Permissions are enforced in `memories.js`**, not only in the UI:
  - `createMemory` throws `PermissionError` for non-members
  - `editMemory` / `deleteMemory` throw for non-owners
  - `deleteComment` throws for non-authors
- Limits: video ≤ 30 MB, caption ≤ 600 chars, comment ≤ 400 chars. Photos are downscaled to 1600 px JPEG before saving.

## Configuration (all in `src/CasaLelePan.jsx` unless noted)

| Constant | Purpose |
|---|---|
| `WHATSAPP_PHONE` | Order destination: `551122563157` (+55 11 2256-3157) |
| `STORE` | Name, address, phone, official Google Maps link (`https://maps.app.goo.gl/17YFRjqcZxg3P5Bz5`) |
| `OPENING_HOURS` / `WEEK_HOURS` | Hours and live open/closed status |
| `DELIVERY_FEE_CONFIG` | `{ mode: "manual", fee: null }`. Set `{ mode: "fixed", fee: 8 }` once Lele Pan defines a fee |
| `CIRCULO_ORDERS_REQUIRED` | Orders needed to unlock Círculo |
| `HERO_MEDIA`, `HERITAGE_MEDIA` | Media slots. Set `src` or `video` to drop in final assets; layout and crop stay the same |
| `KACULA_QUOTE` (`Desde1988.jsx`) | Short quotation from *Casa Verde: Uma Pequena África Paulistana* |

## WhatsApp message format

```
Oi, Lele Pan! 💛
Quero fazer esse pedido:

Pedido #1038

Coxinha × 3
Pão francês × 10

Total: R$XX,XX

Retirada: 18:30

Vou retirar aí na Lele Pan 😊
```

Delivery orders include Subtotal, Entrega (or "a combinar"), Total, and Endereço. The order number is generated automatically.

## Persistence (prototype-grade)

| Where | What |
|---|---|
| `localStorage` | `circulo:profile`, `circulo:completedOrders`, `lelepan:favorites`, `lelepan:memories:v1`, `lelepan:visitor:v1`, `lelepan:visitorName:v1` |
| IndexedDB (`lelepan-media`) | Memory photos and videos |

Identity is a per-browser visitor id. Clearing site data removes everything.

## Testing helpers (browser console)

```js
__lelePanDev.setOrders(5)      // unlock Círculo without 5 real checkouts
__lelePanDev.resetCirculo()    // clear profile + order count
__lelePanDev.seedMemories()    // add 3 clearly-labeled demo text memories
__lelePanDev.clearMemories()   // wipe the wall
```

## Known limits (by design, post-approval work)

- No real payments, order backend, authentication, CRM, or admin dashboard.
- Likes, comments, and memories are per-browser, not shared between visitors.
- Recent orders and Mimos are illustrative mock data.

## Open items for the client

- [ ] Official **Política de Privacidade** and **Termos de Uso** text (pages exist, no legal copy yet)
- [ ] **Delivery fee**
- [ ] Verify the **Kaçula quotation** against the book
- [ ] Final **photos and videos** for the media slots

## Design rules

Preserve the Lele Pan palette, Cormorant Garamond + Inter, rounded button language, motion, and product-card behavior. From V1 on: bug fixes and intentional visual refinements only.
