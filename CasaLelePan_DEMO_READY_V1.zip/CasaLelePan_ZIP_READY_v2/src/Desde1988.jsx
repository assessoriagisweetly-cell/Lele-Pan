import React, { useState, useRef, useEffect, useMemo } from "react";
import {
  useMemories, getMediaUrl, getVisitorId, getVisitorName, setVisitorName,
  createMemory, editMemory, deleteMemory, toggleLike, reportMemory,
  addComment, toggleCommentLike, reportComment, deleteComment,
  MAX_CAPTION, MAX_COMMENT, MAX_VIDEO_MB,
} from "./memories.js";

/* ----------------------------------------------------------------- tiny ui */
const Svg = ({ size = 18, children, ...p }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7"
    strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...p}>{children}</svg>
);
const Heart = ({ filled, size }) => (
  <Svg size={size} fill={filled ? "currentColor" : "none"}>
    <path d="M12 20.5s-7.5-4.6-7.5-10.2A4.3 4.3 0 0 1 12 7.6a4.3 4.3 0 0 1 7.5 2.7c0 5.6-7.5 10.2-7.5 10.2z" />
  </Svg>
);
const Arrow = ({ dir = "right" }) => (
  <Svg size={16}>{dir === "right" ? <path d="M4 12h16M14 6l6 6-6 6" /> : <path d="M20 12H4M10 6l-6 6 6 6" />}</Svg>
);
const Close = () => (<Svg size={20}><path d="M6 6l12 12M18 6L6 18" /></Svg>);
const Play = () => (<Svg size={22} fill="currentColor"><path d="M8 5.5v13l11-6.5z" /></Svg>);

function useReveal() {
  const ref = useRef(null);
  const [shown, setShown] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (typeof IntersectionObserver === "undefined") { setShown(true); return; }
    const io = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) { setShown(true); io.disconnect(); }
    }, { threshold: 0.25 });
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return [ref, shown];
}

const fmtDate = (ts) =>
  new Date(ts).toLocaleDateString("pt-BR", { day: "numeric", month: "long", year: "numeric" });

/* Loads a stored photo/video blob as an object URL. */
function useMediaUrl(memory) {
  const [url, setUrl] = useState(null);
  useEffect(() => {
    let alive = true;
    if (memory.mediaType) getMediaUrl(memory.id).then((u) => alive && setUrl(u));
    return () => { alive = false; };
  }, [memory.id, memory.mediaType]);
  return url;
}

function MemoryMedia({ memory, controls = false, className = "" }) {
  const url = useMediaUrl(memory);
  if (!memory.mediaType) return null;
  if (!url) return <div className={`mem-media mem-media--loading ${className}`} style={{ aspectRatio: memory.aspect || 1 }} />;
  return memory.mediaType === "video" ? (
    <video className={`mem-media ${className}`} src={url} controls={controls} muted={!controls} loop={!controls}
      autoPlay={!controls} playsInline style={{ aspectRatio: memory.aspect || 16 / 9 }} />
  ) : (
    <img className={`mem-media ${className}`} src={url} alt={memory.caption.slice(0, 80)} loading="lazy"
      style={{ aspectRatio: memory.aspect || 1 }} />
  );
}

/* ============================================================================
   COMPOSER — lives inside Círculo (member-only; enforced in memories.js too)
   ============================================================================ */
export function MemoryComposer({ author, onBack, onViewDesde }) {
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(null);
  const [caption, setCaption] = useState("");
  const [context, setContext] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [done, setDone] = useState(false);
  const inputRef = useRef(null);

  useEffect(() => () => preview && URL.revokeObjectURL(preview.url), [preview]);

  const pick = (e) => {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    setError("");
    if (!f.type.startsWith("image/") && !f.type.startsWith("video/")) {
      setError("Escolha uma foto ou um vídeo.");
      return;
    }
    if (f.type.startsWith("video/") && f.size > MAX_VIDEO_MB * 1024 * 1024) {
      setError(`O vídeo é grande demais (máximo ${MAX_VIDEO_MB} MB).`);
      return;
    }
    setFile(f);
    setPreview({ url: URL.createObjectURL(f), video: f.type.startsWith("video/") });
  };

  const publish = async () => {
    setError("");
    if (!file) return setError("Escolha uma foto ou um vídeo.");
    if (!caption.trim()) return setError("Escreva algumas palavras sobre essa memória.");
    setBusy(true);
    try {
      await createMemory({ author, file, caption, context });
      setDone(true);
    } catch (e) {
      setError(e.message || "Não foi possível publicar agora.");
    } finally {
      setBusy(false);
    }
  };

  const reset = () => {
    setFile(null); setPreview(null); setCaption(""); setContext(""); setDone(false); setError("");
  };

  if (!author.isMember) {
    return (
      <div className="composer circulo__intro circulo__intro--revealed">
        <h2 className="circulo__title">Só para quem é do Círculo.</h2>
        <p className="circulo__tagline">Complete seu cadastro para compartilhar uma memória.</p>
      </div>
    );
  }

  if (done) {
    return (
      <div className="composer composer--done circulo__intro circulo__intro--revealed">
        <h2 className="circulo__title">Sua memória já está na casa.</h2>
        <p className="circulo__tagline">Obrigado por fazer parte da história.</p>
        <div className="composer__done-actions">
          <button type="button" className="btn-primary" onClick={onViewDesde}>
            VER NA DESDE 1988 <Arrow />
          </button>
          <button type="button" className="editorial-link" onClick={reset}>COMPARTILHAR OUTRA</button>
          <button type="button" className="editorial-link" onClick={onBack}>VOLTAR AO CÍRCULO</button>
        </div>
      </div>
    );
  }

  return (
    <div className="composer circulo__intro circulo__intro--revealed">
      <button type="button" className="editorial-link composer__back" onClick={onBack}>
        <Arrow dir="left" /> <span>VOLTAR AO CÍRCULO</span>
      </button>
      <h2 className="circulo__title">Compartilhar uma memória</h2>
      <p className="circulo__tagline">Você também faz parte da história.</p>

      <div className="composer__grid">
        <div>
          <input ref={inputRef} type="file" accept="image/*,video/*" onChange={pick} hidden />
          {preview ? (
            <div className="composer__preview">
              {preview.video ? <video src={preview.url} controls playsInline /> : <img src={preview.url} alt="Prévia da sua memória" />}
              <button type="button" className="editorial-link composer__swap" onClick={() => inputRef.current.click()}>
                TROCAR FOTO OU VÍDEO
              </button>
            </div>
          ) : (
            <button type="button" className="composer__drop" onClick={() => inputRef.current.click()}>
              <span className="composer__drop-title">Escolher uma foto ou um vídeo</span>
              <span className="composer__drop-hint">Uma só. Vídeos até {MAX_VIDEO_MB} MB.</span>
            </button>
          )}
        </div>

        <div className="enroll__form">
          <label className="enroll__field">
            <span>Sua memória</span>
            <textarea rows={5} maxLength={MAX_CAPTION} value={caption} onChange={(e) => setCaption(e.target.value)}
              placeholder="Conte o que essa imagem guarda..." />
          </label>
          <label className="enroll__field">
            <span>Quando ou onde? (opcional)</span>
            <input type="text" maxLength={80} value={context} onChange={(e) => setContext(e.target.value)}
              placeholder="Ex.: aniversário da minha mãe, 2009" />
          </label>
          {error && <p className="enroll__field-error" role="alert">{error}</p>}
          <button type="button" className={`btn-primary enroll__submit ${busy ? "btn-primary--disabled" : ""}`}
            onClick={publish} disabled={busy}>
            {busy ? "PUBLICANDO…" : "PUBLICAR"} {!busy && <Arrow />}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ============================================================================
   MEMORY DETAIL — view, like, comment, report, edit/delete own
   ============================================================================ */
function MemoryDetail({ memory, memberName, onClose }) {
  const vid = getVisitorId();
  const isOwner = memory.authorId === vid;
  const [editing, setEditing] = useState(false);
  const [capDraft, setCapDraft] = useState(memory.caption);
  const [ctxDraft, setCtxDraft] = useState(memory.context || "");
  const [confirmDel, setConfirmDel] = useState(false);
  const [name, setName] = useState(memberName || getVisitorName());
  const [text, setText] = useState("");
  const [error, setError] = useState("");
  const liked = memory.likes.includes(vid);
  const reported = memory.reports.includes(vid);

  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { window.removeEventListener("keydown", onKey); document.body.style.overflow = prev; };
  }, [onClose]);

  const saveEdit = () => {
    try { editMemory({ id: memory.id, visitorId: vid, caption: capDraft, context: ctxDraft }); setEditing(false); setError(""); }
    catch (e) { setError(e.message); }
  };
  const remove = () => {
    try { deleteMemory({ id: memory.id, visitorId: vid }); onClose(); } catch (e) { setError(e.message); }
  };
  const send = () => {
    try {
      addComment({ id: memory.id, visitorId: vid, name: memberName || name, text });
      if (!memberName) setVisitorName(name.trim());
      setText(""); setError("");
    } catch (e) { setError(e.message); }
  };
  const safe = (fn) => { try { fn(); } catch (e) { setError(e.message); } };

  return (
    <div className="mem-modal" role="dialog" aria-modal="true" aria-label="Memória da casa">
      <div className="mem-modal__scrim" onClick={onClose} />
      <div className="mem-modal__panel">
        <button type="button" className="mem-modal__close" onClick={onClose} aria-label="Fechar"><Close /></button>
        <div className="mem-modal__grid">
          {memory.mediaType && (
            <div className="mem-modal__media"><MemoryMedia memory={memory} controls /></div>
          )}
          <div className="mem-modal__body">
            <p className="mem-meta">
              <strong>{memory.authorName}</strong>
              {memory.context ? ` · ${memory.context}` : ""} · {fmtDate(memory.createdAt)}
              {memory.edited ? " · editada" : ""}
            </p>

            {editing ? (
              <div className="mem-edit">
                <textarea rows={4} maxLength={MAX_CAPTION} value={capDraft} onChange={(e) => setCapDraft(e.target.value)} />
                <input type="text" maxLength={80} value={ctxDraft} onChange={(e) => setCtxDraft(e.target.value)}
                  placeholder="Quando ou onde? (opcional)" />
                <div className="mem-row">
                  <button type="button" className="mem-btn mem-btn--solid" onClick={saveEdit}>SALVAR</button>
                  <button type="button" className="mem-btn" onClick={() => { setEditing(false); setCapDraft(memory.caption); }}>CANCELAR</button>
                </div>
              </div>
            ) : (
              <p className="mem-caption">{memory.caption}</p>
            )}

            <div className="mem-row mem-row--actions">
              <button type="button" className={`mem-like ${liked ? "mem-like--on" : ""}`}
                onClick={() => toggleLike({ id: memory.id, visitorId: vid })} aria-pressed={liked}>
                <Heart filled={liked} size={18} /> {memory.likes.length > 0 ? memory.likes.length : ""}
                <span className="sr-only">{liked ? "Descurtir" : "Curtir"}</span>
              </button>
              {isOwner && !editing && (
                <>
                  <button type="button" className="mem-btn" onClick={() => setEditing(true)}>EDITAR MINHA PUBLICAÇÃO</button>
                  {confirmDel ? (
                    <>
                      <button type="button" className="mem-btn mem-btn--danger" onClick={remove}>CONFIRMAR EXCLUSÃO</button>
                      <button type="button" className="mem-btn" onClick={() => setConfirmDel(false)}>NÃO</button>
                    </>
                  ) : (
                    <button type="button" className="mem-btn" onClick={() => setConfirmDel(true)}>EXCLUIR MINHA PUBLICAÇÃO</button>
                  )}
                </>
              )}
              {!isOwner && (
                reported
                  ? <span className="mem-note">Denúncia enviada. Obrigado.</span>
                  : <button type="button" className="mem-btn" onClick={() => reportMemory({ id: memory.id, visitorId: vid })}>DENUNCIAR</button>
              )}
            </div>

            <div className="mem-comments">
              <p className="mem-eyebrow">
                {memory.comments.length === 0 ? "Ainda sem comentários" : `${memory.comments.length} ${memory.comments.length === 1 ? "comentário" : "comentários"}`}
              </p>
              <ul>
                {memory.comments.map((c) => {
                  const mine = c.authorId === vid;
                  const cLiked = c.likes.includes(vid);
                  const cReported = c.reports.includes(vid);
                  if (cReported && !mine) return <li key={c.id} className="mem-comment mem-note">Você denunciou este comentário.</li>;
                  return (
                    <li key={c.id} className="mem-comment">
                      <p><strong>{c.authorName}</strong> {c.text}</p>
                      <div className="mem-row mem-row--tiny">
                        <button type="button" className={`mem-like mem-like--small ${cLiked ? "mem-like--on" : ""}`}
                          onClick={() => toggleCommentLike({ id: memory.id, commentId: c.id, visitorId: vid })}
                          aria-pressed={cLiked} aria-label={cLiked ? "Descurtir comentário" : "Curtir comentário"}>
                          <Heart filled={cLiked} size={14} /> {c.likes.length > 0 ? c.likes.length : ""}
                        </button>
                        {mine ? (
                          <button type="button" className="mem-btn mem-btn--tiny"
                            onClick={() => safe(() => deleteComment({ id: memory.id, commentId: c.id, visitorId: vid }))}>EXCLUIR MEU COMENTÁRIO</button>
                        ) : (
                          <button type="button" className="mem-btn mem-btn--tiny"
                            onClick={() => reportComment({ id: memory.id, commentId: c.id, visitorId: vid })}>DENUNCIAR</button>
                        )}
                      </div>
                    </li>
                  );
                })}
              </ul>

              <div className="mem-form">
                {!memberName && (
                  <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Seu nome" maxLength={40} aria-label="Seu nome" />
                )}
                <textarea rows={2} value={text} maxLength={MAX_COMMENT} onChange={(e) => setText(e.target.value)}
                  placeholder="Deixe uma palavra carinhosa…" aria-label="Comentário" />
                <button type="button" className="mem-btn mem-btn--solid" onClick={send}>COMENTAR</button>
              </div>
              {error && <p className="mem-error" role="alert">{error}</p>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ============================================================================
   MEMORY WALL
   ============================================================================ */
function MemoryCard({ memory, onOpen }) {
  const vid = getVisitorId();
  const isOwner = memory.authorId === vid;
  const hidden = !isOwner && (memory.reports.includes(vid) || memory.reports.length >= 3);
  const shape = !memory.mediaType ? "text" : memory.aspect > 1.25 ? "wide" : memory.aspect < 0.85 ? "tall" : "square";
  const liked = memory.likes.includes(vid);

  if (hidden) {
    return (
      <li className="wall__item">
        <div className="wall__card wall__card--hidden">Conteúdo em análise.</div>
      </li>
    );
  }
  return (
    <li className={`wall__item wall__item--${shape}`}>
      <button type="button" className={`wall__card wall__card--${shape}`} onClick={() => onOpen(memory.id)}
        aria-label={`Abrir memória de ${memory.authorName}`}>
        {memory.mediaType && (
          <span className="wall__photo">
            <MemoryMedia memory={memory} />
            {memory.mediaType === "video" && <span className="wall__play"><Play /></span>}
          </span>
        )}
        <span className="wall__text">
          <span className={shape === "text" ? "wall__quote" : "wall__caption"}>{memory.caption}</span>
          <span className="wall__meta">
            {memory.authorName}{memory.context ? ` · ${memory.context}` : ""}
          </span>
          {(memory.likes.length > 0 || memory.comments.length > 0) && (
            <span className="wall__engage">
              <Heart filled={liked} size={12} /> {memory.likes.length}
              {memory.comments.length > 0 && ` · ${memory.comments.length} ${memory.comments.length === 1 ? "comentário" : "comentários"}`}
            </span>
          )}
        </span>
      </button>
    </li>
  );
}

function MemoryWall({ memberName }) {
  const memories = useMemories();
  const [openId, setOpenId] = useState(null);
  const open = memories.find((m) => m.id === openId) || null;

  if (memories.length === 0) {
    return (
      <div className="wall__empty">
        <p className="wall__empty-title">O mural está esperando a primeira memória.</p>
        <p>Quando alguém do Círculo Lele compartilhar uma foto ou um vídeo, ele aparece aqui.</p>
      </div>
    );
  }
  return (
    <>
      <ul className="wall">
        {memories.map((m) => <MemoryCard key={m.id} memory={m} onOpen={setOpenId} />)}
      </ul>
      {open && <MemoryDetail memory={open} memberName={memberName} onClose={() => setOpenId(null)} />}
    </>
  );
}

/* ============================================================================
   DESDE 1988 — public experience
   ============================================================================ */
// Short quotation only. Keep it exactly as verified in the book before launch.
const KACULA_QUOTE = "…tomar um café com seu Carlão do Peruche na Le Pan…";

function Chapter({ n, title, lines, children, tone = "light" }) {
  const [ref, shown] = useReveal();
  return (
    <section ref={ref} className={`d88__chapter d88__chapter--${tone} ${shown ? "d88--in" : ""}`}>
      <div className="container d88__chapter-inner">
        <p className="d88__chapter-n">{String(n).padStart(2, "0")}</p>
        <div>
          <h2 className="d88__chapter-title">{title}</h2>
          {lines.map((l, i) => <p key={i} className={i === 0 ? "d88__lead" : "d88__p"}>{l}</p>)}
          {children}
        </div>
      </div>
    </section>
  );
}

export function Desde1988Page({ isMember, memberName, onBack, onGoCirculo }) {
  const [introRef, introShown] = useReveal();
  const [wallRef, wallShown] = useReveal();
  return (
    <div className="d88">
      <section className="d88__hero">
        <div className="container">
          <button type="button" className="editorial-link d88__back" onClick={onBack}>
            <Arrow dir="left" /> <span>VOLTAR PARA A CASA</span>
          </button>
          <h1 className="d88__title">DESDE 1988</h1>
          <p className="d88__scroll">Role devagar.</p>
        </div>
      </section>

      <section ref={introRef} className={`d88__statement ${introShown ? "d88--in" : ""}`}>
        <div className="container">
          <p className="d88__big">Algumas casas são feitas de paredes.</p>
          <p className="d88__big d88__big--late">Outras, de tudo o que aconteceu dentro delas.</p>
          <p className="d88__then">Desde 1988, a Lele Pan faz parte de muitos momentos.</p>
        </div>
      </section>

      <Chapter n={1} title="TEMPO" lines={[
        "Uma padaria conta o tempo em fornadas.",
        "Cedo, o pão. Depois, o café. No fim do dia, alguém passa só para levar o que faltava em casa.",
      ]} />
      <Chapter n={2} title="CASA" tone="cream" lines={[
        "Uma casa não é só endereço.",
        "É a porta que se reconhece de longe, o balcão onde se espera a vez, o cheiro que chega antes de você.",
      ]} />
      <Chapter n={3} title="BAIRRO" lines={[
        "A Lele Pan fica na Casa Verde, em São Paulo.",
        "E o bairro também já escreveu sobre ela.",
      ]}>
        <figure className="d88__artifact">
          <blockquote>{KACULA_QUOTE}</blockquote>
          <figcaption>
            — Tadeu Kaçula<br />
            <em>Casa Verde: Uma Pequena África Paulistana</em>
          </figcaption>
        </figure>
      </Chapter>
      <Chapter n={4} title="PESSOAS" tone="cream" lines={[
        "Quem passa muda a cada dia.",
        "Quem volta também faz a casa.",
      ]} />
      <Chapter n={5} title="MEMÓRIA" lines={[
        "Toda casa guarda o que ninguém escreveu.",
        "Um aniversário, um café, um pão levado para quem estava chegando. Guardar isso também é ofício.",
      ]} />
      <Chapter n={6} title="O QUE FICA" tone="dark" lines={[
        "Tudo muda com o tempo.",
        "Mas o cheiro de pão quentinho de manhã cedo é sempre o mesmo.",
      ]} />

      <section id="memorias-da-casa" ref={wallRef} className={`d88__wall-section ${wallShown ? "d88--in" : ""}`}>
        <div className="container">
          <p className="mem-eyebrow">Desde 1988</p>
          <h2 className="d88__wall-title">Memórias da casa</h2>
          <p className="d88__wall-sub">Fotos e vídeos de quem já passou por aqui. Qualquer pessoa pode ver, curtir e comentar.</p>
          <div className="d88__wall-cta">
            {isMember ? (
              <button type="button" className="btn-primary" onClick={onGoCirculo}>
                COMPARTILHAR UMA MEMÓRIA <Arrow />
              </button>
            ) : (
              <p className="d88__wall-note">
                Quem é do Círculo Lele pode compartilhar uma memória.{" "}
                <button type="button" className="d88__inline-link" onClick={onGoCirculo}>Conheça o Círculo</button>
              </p>
            )}
          </div>
          <MemoryWall memberName={memberName} />
        </div>
      </section>
    </div>
  );
}

/* ============================================================================
   LEGAL — destination structure only; no legal copy is invented
   ============================================================================ */
export function LegalPage({ kind, contact, onBack }) {
  const title = kind === "termos" ? "Termos de Uso" : "Política de Privacidade";
  return (
    <section className="legal">
      <div className="container legal__inner">
        <button type="button" className="editorial-link" onClick={onBack}>
          <Arrow dir="left" /> <span>VOLTAR PARA A CASA</span>
        </button>
        <h1 className="legal__title">{title}</h1>
        <p className="legal__p">
          O texto oficial deste documento será publicado aqui assim que for fornecido pela Lele Pan.
        </p>
        <p className="legal__p">
          Enquanto isso, se tiver qualquer dúvida, fale com a gente:{" "}
          <a href={`tel:+${contact.phoneDigits}`}>{contact.phoneDisplay}</a>.
        </p>
      </div>
    </section>
  );
}

/* ============================================================================
   STYLES for everything above (uses the tokens defined on .lele-root)
   ============================================================================ */
export const DESDE_STYLES = `
.sr-only { position:absolute; width:1px; height:1px; overflow:hidden; clip:rect(0 0 0 0); white-space:nowrap; }

/* composer (inside Círculo overlay) */
.composer__back { margin-bottom: 32px; color: var(--white); }
.composer__grid { display:grid; grid-template-columns: 1fr 1fr; gap: 56px; margin-top: 56px; align-items:start; }
@media (max-width: 900px) { .composer__grid { grid-template-columns: 1fr; gap: 32px; margin-top: 40px; } }
.composer__drop { width:100%; aspect-ratio:4/5; border:1px dashed rgba(248,248,246,.35); border-radius: var(--radius-l);
  display:flex; flex-direction:column; align-items:center; justify-content:center; gap:8px; color:var(--white); cursor:pointer;
  transition: border-color var(--t-micro) var(--ease-out), background var(--t-micro) var(--ease-out); padding: 24px; text-align:center; }
.composer__drop:hover { border-color: var(--white); background: rgba(248,248,246,.04); }
.composer__drop-title { font-family: var(--font-display); font-size: var(--fs-h-s); }
.composer__drop-hint { font-size: var(--fs-body-s); opacity:.55; }
.composer__preview img, .composer__preview video { width:100%; max-height: 70vh; object-fit:cover; border-radius: var(--radius-l); display:block; background:#000; }
.composer__swap { margin-top:16px; color: var(--white); }
.composer__done-actions { margin-top:40px; display:flex; flex-wrap:wrap; gap:20px 28px; align-items:center; }
.composer__done-actions .editorial-link { color: var(--white); }
.composer .enroll__field textarea, .composer .enroll__field input { width:100%; }

/* Círculo additions */
.circulo__actions { display:flex; flex-direction:column; gap:20px; padding-top:56px; border-top:1px solid rgba(248,248,246,.12); }
.circulo__share-line { font-family: var(--font-display); font-style:italic; font-size: var(--fs-h-s); max-width: 30ch; }
.circulo__share-row { display:flex; flex-wrap:wrap; gap:16px 28px; align-items:center; }
.circulo__share-row .editorial-link { color: var(--white); }
.circulo__welcome .btn-primary { margin-top: 32px; }
.circulo__welcome-links { margin-top:24px; }
.profile__saved { font-size: var(--fs-body-s); color: var(--gold); }

/* footer */
.footer__links { display:flex; gap:20px; flex-wrap:wrap; }
.footer__link { font-size: var(--fs-body-s); opacity:.55; cursor:pointer; text-decoration:underline; text-underline-offset:3px; transition: opacity var(--t-micro) var(--ease-out); }
.footer__link:hover { opacity:1; }

/* legal */
.legal { padding: 140px 0 120px; min-height: 70vh; }
.legal__inner { max-width: 720px; margin-left:auto; margin-right:auto; }
.legal__title { font-family: var(--font-display); font-weight:500; font-size: var(--fs-display-m); margin: 32px 0 24px; }
.legal__p { font-size: var(--fs-body-l); opacity:.75; margin-bottom: 16px; }
.legal__p a { text-decoration: underline; text-underline-offset:3px; }

/* heritage link on home */
.heritage__cta { margin-top: 32px; }

/* book reference on home */
.memorias__source { margin-top: 12px; font-size: var(--fs-body-s); opacity:.55; }
.memorias__source em { font-style: italic; }

/* ---------------------------------------------------------- Desde 1988 */
.d88 { padding-top: 0; }
.d88__hero { min-height: 100vh; min-height: 100svh; background: var(--black); color: var(--white); display:flex; align-items:center; position:relative; }
.d88__back { color: var(--white); position:absolute; top: 96px; }
.d88__title { font-family: var(--font-display); font-weight:500; font-size: var(--fs-display-xl); letter-spacing:.01em; animation: surpriseIn var(--t-cinematic) var(--ease-out) both; }
.d88__scroll { margin-top: 24px; font-size: var(--fs-body-s); opacity:.45; letter-spacing:.06em; }

.d88__statement { background: var(--black); color: var(--white); padding: 40px 0 200px; }
@media (max-width: 767px) { .d88__statement { padding-bottom: 120px; } }
.d88__big { font-family: var(--font-display); font-style:italic; font-size: var(--fs-display-m); line-height:1.15; max-width: 22ch; opacity:0; transform: translateY(16px);
  transition: opacity 1.2s var(--ease-out), transform 1.2s var(--ease-out); }
.d88__big--late { margin-top: 16px; transition-delay: .7s; }
.d88__then { margin-top: 72px; font-size: var(--fs-body-l); opacity:0; transition: opacity 1.2s var(--ease-out) 1.6s; max-width: 34ch; }
.d88--in .d88__big { opacity:1; transform:none; }
.d88--in .d88__then { opacity:.7; }

.d88__chapter { padding: 120px 0; opacity:0; transform: translateY(20px); transition: opacity var(--t-cinematic) var(--ease-out), transform var(--t-cinematic) var(--ease-out); }
.d88__chapter.d88--in { opacity:1; transform:none; }
@media (max-width: 767px) { .d88__chapter { padding: 72px 0; } }
.d88__chapter--light { background: var(--white); }
.d88__chapter--cream { background: var(--cream); }
.d88__chapter--dark { background: var(--black); color: var(--white); }
.d88__chapter-inner { display:grid; grid-template-columns: 120px 1fr; gap: 32px; align-items:start; }
@media (max-width: 767px) { .d88__chapter-inner { grid-template-columns: 1fr; gap: 12px; } }
.d88__chapter-n { font-family: var(--font-display); font-size: var(--fs-h-m); opacity:.35; }
.d88__chapter-title { font-size: var(--fs-label-l); font-weight:600; letter-spacing:.14em; opacity:.6; margin-bottom: 28px; }
.d88__lead { font-family: var(--font-display); font-size: var(--fs-display-m); line-height:1.15; max-width: 22ch; }
.d88__p { margin-top: 24px; font-size: var(--fs-body-l); opacity:.75; max-width: 44ch; }
.d88__artifact { margin: 48px 0 0; padding: 32px 36px; max-width: 520px; background: var(--cream); border-left: 3px solid var(--gold); border-radius: 0 var(--radius-m) var(--radius-m) 0; }
.d88__chapter--cream .d88__artifact { background: var(--white); }
.d88__artifact blockquote { font-family: var(--font-display); font-style:italic; font-size: var(--fs-h-m); line-height:1.25; }
.d88__artifact figcaption { margin-top: 20px; font-size: var(--fs-body-s); opacity:.6; line-height:1.6; }

.d88__wall-section { padding: 120px 0 160px; background: var(--white); opacity:0; transform: translateY(20px); transition: opacity var(--t-cinematic) var(--ease-out), transform var(--t-cinematic) var(--ease-out); }
.d88__wall-section.d88--in { opacity:1; transform:none; }
@media (max-width: 767px) { .d88__wall-section { padding: 72px 0 120px; } }
.d88__wall-title { font-family: var(--font-display); font-weight:500; font-size: var(--fs-display-l); }
.d88__wall-sub { margin-top: 16px; font-size: var(--fs-body-l); opacity:.65; max-width: 44ch; }
.d88__wall-cta { margin: 32px 0 64px; }
.d88__wall-note { font-size: var(--fs-body-m); opacity:.75; }
.d88__inline-link { text-decoration: underline; text-underline-offset:3px; cursor:pointer; font-weight:500; }
.mem-eyebrow { font-size: var(--fs-label-l); font-weight:600; letter-spacing:.06em; opacity:.55; margin-bottom: 16px; }

/* wall */
.wall { column-count: 3; column-gap: 28px; }
@media (max-width: 1023px) { .wall { column-count: 2; column-gap: 20px; } }
@media (max-width: 599px) { .wall { column-count: 1; } }
.wall__item { break-inside: avoid; margin-bottom: 28px; }
@media (max-width: 1023px) { .wall__item { margin-bottom: 20px; } }
.wall__item:nth-child(3n+2) { padding-top: 24px; }
@media (max-width: 599px) { .wall__item:nth-child(3n+2) { padding-top: 0; } }
.wall__card { display:block; width:100%; text-align:left; cursor:pointer; background:#fff; padding: 10px 10px 18px; border-radius: var(--radius-s);
  box-shadow: 0 1px 2px rgba(23,23,23,.08), 0 10px 28px rgba(23,23,23,.06); transition: transform var(--t-standard) var(--ease-out), box-shadow var(--t-standard) var(--ease-out); }
.wall__card:hover { transform: translateY(-3px); box-shadow: 0 2px 4px rgba(23,23,23,.08), 0 18px 36px rgba(23,23,23,.1); }
.wall__card:active { transform: scale(.99); }
.wall__card--text { background: var(--cream); padding: 32px 28px; box-shadow:none; border:1px solid rgba(23,23,23,.08); }
.wall__card--hidden { cursor:default; padding: 28px; font-size: var(--fs-body-s); opacity:.5; background: var(--cream); box-shadow:none; }
.wall__photo { display:block; position:relative; overflow:hidden; border-radius: 3px; background: var(--cream); }
.wall__play { position:absolute; right:12px; bottom:12px; width:38px; height:38px; border-radius:50%; background: rgba(23,23,23,.6); color:#fff; display:flex; align-items:center; justify-content:center; }
.wall__text { display:flex; flex-direction:column; gap:10px; padding: 16px 6px 0; }
.wall__card--text .wall__text { padding: 0; }
.wall__caption { font-family: var(--font-display); font-size: 20px; line-height:1.3; display:-webkit-box; -webkit-line-clamp:4; -webkit-box-orient:vertical; overflow:hidden; }
.wall__quote { font-family: var(--font-display); font-style:italic; font-size: var(--fs-h-s); line-height:1.3; }
.wall__meta { font-size: var(--fs-label-s); opacity:.55; letter-spacing:.02em; }
.wall__engage { display:inline-flex; align-items:center; gap:5px; font-size: var(--fs-label-s); opacity:.45; }
.mem-media { display:block; width:100%; height:auto; object-fit:cover; background: var(--cream); }
.mem-media--loading { animation: memPulse 1.4s ease-in-out infinite; }
@keyframes memPulse { 0%,100% { opacity:.6; } 50% { opacity:1; } }
.wall__empty { padding: 72px 32px; border:1px dashed rgba(23,23,23,.25); border-radius: var(--radius-l); text-align:center; max-width: 560px; margin: 0 auto; opacity:.8; }
.wall__empty-title { font-family: var(--font-display); font-size: var(--fs-h-m); margin-bottom: 12px; }

/* detail modal */
.mem-modal { position:fixed; inset:0; z-index:80; display:flex; align-items:center; justify-content:center; padding: 24px; }
.mem-modal__scrim { position:absolute; inset:0; background: rgba(23,23,23,.72); }
.mem-modal__panel { position:relative; background: var(--white); border-radius: var(--radius-l); width:100%; max-width: 1040px; max-height: 92vh; overflow-y:auto; animation: surpriseIn var(--t-standard) var(--ease-out) both; }
.mem-modal__close { position:absolute; top:14px; right:14px; z-index:2; width:40px; height:40px; border-radius:50%; background: rgba(248,248,246,.9); display:flex; align-items:center; justify-content:center; cursor:pointer; }
.mem-modal__grid { display:grid; grid-template-columns: 1.1fr 1fr; }
.mem-modal__grid:has(.mem-modal__media) { }
.mem-modal__grid > .mem-modal__body:only-child { grid-column: 1 / -1; max-width: 640px; margin: 0 auto; }
@media (max-width: 800px) { .mem-modal { padding:0; align-items:flex-end; } .mem-modal__panel { max-height: 94vh; border-radius: var(--radius-l) var(--radius-l) 0 0; } .mem-modal__grid { grid-template-columns: 1fr; } }
.mem-modal__media { background:#000; display:flex; align-items:center; }
.mem-modal__media .mem-media { max-height: 88vh; object-fit: contain; }
.mem-modal__body { padding: 40px 36px; display:flex; flex-direction:column; gap: 20px; }
@media (max-width: 800px) { .mem-modal__body { padding: 28px 22px 40px; } }
.mem-meta { font-size: var(--fs-body-s); opacity:.6; }
.mem-meta strong { font-weight:600; opacity:1; }
.mem-caption { font-family: var(--font-display); font-size: var(--fs-h-m); line-height:1.25; }
.mem-row { display:flex; flex-wrap:wrap; gap: 10px 16px; align-items:center; }
.mem-row--tiny { margin-top: 6px; gap: 6px 14px; }
.mem-btn { font-size: var(--fs-label-s); font-weight:600; letter-spacing:.05em; opacity:.6; cursor:pointer; padding: 6px 0; transition: opacity var(--t-micro) var(--ease-out); }
.mem-btn:hover { opacity:1; }
.mem-btn--solid { opacity:1; background: var(--gold); padding: 0 18px; height:40px; border-radius: var(--radius-m); }
.mem-btn--solid:hover { background: var(--gold-deep); }
.mem-btn--danger { color: var(--brick); opacity:1; }
.mem-btn--tiny { font-size: 10px; padding: 2px 0; }
.mem-note { font-size: var(--fs-label-s); opacity:.55; }
.mem-like { display:inline-flex; align-items:center; gap:6px; font-size: var(--fs-body-s); cursor:pointer; opacity:.7; transition: opacity var(--t-micro) var(--ease-out), transform var(--t-micro) var(--ease-out); }
.mem-like:hover { opacity:1; } .mem-like:active { transform: scale(.92); }
.mem-like--on { color: var(--brick); opacity:1; }
.mem-like--small { font-size: var(--fs-label-s); }
.mem-edit { display:flex; flex-direction:column; gap:10px; }
.mem-edit textarea, .mem-edit input, .mem-form textarea, .mem-form input { font: inherit; font-size: var(--fs-body-m); padding: 10px 12px; border:1px solid rgba(23,23,23,.2); border-radius: var(--radius-m); background: transparent; resize:none; width:100%; }
.mem-edit textarea:focus, .mem-edit input:focus, .mem-form textarea:focus, .mem-form input:focus { outline:none; border-color: var(--black); }
.mem-comments { border-top:1px solid rgba(23,23,23,.1); padding-top: 20px; }
.mem-comments ul { display:flex; flex-direction:column; gap: 16px; margin-bottom: 20px; }
.mem-comment p { font-size: var(--fs-body-s); line-height:1.5; }
.mem-comment strong { font-weight:600; margin-right:4px; }
.mem-form { display:flex; flex-direction:column; gap:10px; align-items:flex-start; }
.mem-error { margin-top: 10px; font-size: var(--fs-label-s); color: var(--brick); }
`;
