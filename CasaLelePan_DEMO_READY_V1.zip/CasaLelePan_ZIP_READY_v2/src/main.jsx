import React from 'react';
import { createRoot } from 'react-dom/client';
import CasaLelePan from './CasaLelePan.jsx';

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <CasaLelePan />
  </React.StrictMode>
);
