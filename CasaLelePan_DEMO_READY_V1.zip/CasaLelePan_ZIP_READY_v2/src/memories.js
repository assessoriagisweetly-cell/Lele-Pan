/* ============================================================================
   MEMÓRIAS DA CASA — data layer (prototype)
   ----------------------------------------------------------------------------
   Metadata lives in localStorage; photo/video blobs live in IndexedDB (too big
   for localStorage). Permissions are enforced HERE, not only in the UI:
     - createMemory / editMemory / deleteMemory throw unless the caller is a
       Círculo member (create) or the owner (edit/delete).
     - like / comment / report are open to everyone.
   Identity is a per-browser visitor id. A real backend must replace this with
   authenticated accounts and server-side checks.
   ============================================================================ */
import { useSyncExternalStore } from "react";

const MEM_KEY = "lelepan:memories:v1";
const VID_KEY = "lelepan:visitor:v1";
const VNAME_KEY = "lelepan:visitorName:v1";
const DB_NAME = "lelepan-media";
const STORE_NAME = "blobs";

export const MAX_VIDEO_MB = 30;
export const MAX_CAPTION = 600;
export const MAX_COMMENT = 400;

export class PermissionError extends Error {
  constructor(msg) {
    super(msg);
    this.name = "PermissionError";
  }
}

/* ------------------------------------------------------------ tiny helpers */
function lsGet(key) {
  try { return window.localStorage.getItem(key); } catch (e) { return null; }
}
function lsSet(key, value) {
  try { window.localStorage.setItem(key, value); return true; } catch (e) { return false; }
}
const uid = (p) => `${p}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;

export function getVisitorId() {
  let id = lsGet(VID_KEY);
  if (!id) {
    id = uid("v");
    lsSet(VID_KEY, id);
  }
  return id;
}
export const getVisitorName = () => lsGet(VNAME_KEY) || "";
export const setVisitorName = (n) => lsSet(VNAME_KEY, n);

/* ------------------------------------------------------------------ store */
let memories = [];
const listeners = new Set();
const emit = () => listeners.forEach((l) => l());

function readAll() {
  try {
    const raw = lsGet(MEM_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch (e) {
    return [];
  }
}
function commit(next) {
  memories = next;
  lsSet(MEM_KEY, JSON.stringify(next));
  emit();
}
if (typeof window !== "undefined") {
  memories = readAll();
  window.addEventListener("storage", (e) => {
    if (e.key === MEM_KEY) { memories = readAll(); emit(); }
  });
}
const subscribe = (cb) => { listeners.add(cb); return () => listeners.delete(cb); };
const getSnapshot = () => memories;

export function useMemories() {
  const list = useSyncExternalStore(subscribe, getSnapshot, getSnapshot);
  // newest first
  return [...list].sort((a, b) => b.createdAt - a.createdAt);
}

/* --------------------------------------------------------------- IndexedDB */
function openDB() {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") return reject(new Error("no-idb"));
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE_NAME);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
async function putBlob(id, blob) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    tx.objectStore(STORE_NAME).put(blob, id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}
async function getBlob(id) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const req = db.transaction(STORE_NAME).objectStore(STORE_NAME).get(id);
    req.onsuccess = () => resolve(req.result || null);
    req.onerror = () => reject(req.error);
  });
}
async function delBlob(id) {
  try {
    const db = await openDB();
    db.transaction(STORE_NAME, "readwrite").objectStore(STORE_NAME).delete(id);
  } catch (e) { /* best-effort */ }
}

const urlCache = new Map();
export async function getMediaUrl(id) {
  if (urlCache.has(id)) return urlCache.get(id);
  try {
    const blob = await getBlob(id);
    if (!blob) return null;
    const url = URL.createObjectURL(blob);
    urlCache.set(id, url);
    return url;
  } catch (e) {
    return null;
  }
}

/* Downscale photos so they persist comfortably (max 1600px, JPEG 0.85). */
function processImage(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const max = 1600;
      const scale = Math.min(1, max / Math.max(img.width, img.height));
      const w = Math.round(img.width * scale);
      const h = Math.round(img.height * scale);
      const canvas = document.createElement("canvas");
      canvas.width = w;
      canvas.height = h;
      canvas.getContext("2d").drawImage(img, 0, 0, w, h);
      canvas.toBlob(
        (blob) => {
          URL.revokeObjectURL(url);
          blob ? resolve({ blob, aspect: w / h }) : reject(new Error("image-failed"));
        },
        "image/jpeg",
        0.85
      );
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("image-failed")); };
    img.src = url;
  });
}
function probeVideo(file) {
  return new Promise((resolve) => {
    const url = URL.createObjectURL(file);
    const v = document.createElement("video");
    v.preload = "metadata";
    v.onloadedmetadata = () => {
      const aspect = v.videoWidth && v.videoHeight ? v.videoWidth / v.videoHeight : 16 / 9;
      URL.revokeObjectURL(url);
      resolve({ blob: file, aspect });
    };
    v.onerror = () => { URL.revokeObjectURL(url); resolve({ blob: file, aspect: 16 / 9 }); };
    v.src = url;
  });
}

/* ------------------------------------------------------------ permissions */
// author = { id, name, isMember }
function requireMember(author) {
  if (!author || !author.isMember) {
    throw new PermissionError("Só membros do Círculo Lele podem compartilhar memórias.");
  }
}
function requireOwner(mem, visitorId) {
  if (!mem || mem.authorId !== visitorId) {
    throw new PermissionError("Você só pode alterar o que você mesmo publicou.");
  }
}
const mapOne = (id, fn) => memories.map((m) => (m.id === id ? fn(m) : m));

/* ---------------------------------------------------------------- actions */
export async function createMemory({ author, file, caption, context }) {
  requireMember(author);
  if (!file) throw new Error("Escolha uma foto ou um vídeo.");
  const text = (caption || "").trim();
  if (!text) throw new Error("Escreva algumas palavras sobre essa memória.");

  const isVideo = file.type.startsWith("video/");
  const isImage = file.type.startsWith("image/");
  if (!isVideo && !isImage) throw new Error("Use uma foto ou um vídeo.");
  if (isVideo && file.size > MAX_VIDEO_MB * 1024 * 1024) {
    throw new Error(`O vídeo é grande demais (máximo ${MAX_VIDEO_MB} MB).`);
  }

  const { blob, aspect } = isVideo ? await probeVideo(file) : await processImage(file);
  const id = uid("m");
  try {
    await putBlob(id, blob);
  } catch (e) {
    throw new Error("Não conseguimos guardar a mídia neste navegador.");
  }

  const memory = {
    id,
    authorId: author.id,
    authorName: author.name,
    caption: text.slice(0, MAX_CAPTION),
    context: (context || "").trim().slice(0, 80),
    mediaType: isVideo ? "video" : "image",
    aspect,
    createdAt: Date.now(),
    edited: false,
    likes: [],
    reports: [],
    comments: [],
  };
  commit([memory, ...memories]);
  return memory;
}

export function editMemory({ id, visitorId, caption, context }) {
  const mem = memories.find((m) => m.id === id);
  requireOwner(mem, visitorId);
  const text = (caption || "").trim();
  if (!text) throw new Error("A memória precisa de algumas palavras.");
  commit(mapOne(id, (m) => ({
    ...m,
    caption: text.slice(0, MAX_CAPTION),
    context: (context || "").trim().slice(0, 80),
    edited: true,
  })));
}

export function deleteMemory({ id, visitorId }) {
  const mem = memories.find((m) => m.id === id);
  requireOwner(mem, visitorId);
  delBlob(id);
  urlCache.delete(id);
  commit(memories.filter((m) => m.id !== id));
}

const toggle = (arr, v) => (arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v]);

export function toggleLike({ id, visitorId }) {
  commit(mapOne(id, (m) => ({ ...m, likes: toggle(m.likes, visitorId) })));
}

export function reportMemory({ id, visitorId }) {
  commit(mapOne(id, (m) => (m.reports.includes(visitorId) ? m : { ...m, reports: [...m.reports, visitorId] })));
}

export function addComment({ id, visitorId, name, text }) {
  const body = (text || "").trim();
  const who = (name || "").trim();
  if (!who) throw new Error("Diga seu nome para comentar.");
  if (!body) throw new Error("Escreva um comentário.");
  const comment = {
    id: uid("c"),
    authorId: visitorId,
    authorName: who,
    text: body.slice(0, MAX_COMMENT),
    createdAt: Date.now(),
    likes: [],
    reports: [],
  };
  commit(mapOne(id, (m) => ({ ...m, comments: [...m.comments, comment] })));
}

export function toggleCommentLike({ id, commentId, visitorId }) {
  commit(mapOne(id, (m) => ({
    ...m,
    comments: m.comments.map((c) => (c.id === commentId ? { ...c, likes: toggle(c.likes, visitorId) } : c)),
  })));
}

export function reportComment({ id, commentId, visitorId }) {
  commit(mapOne(id, (m) => ({
    ...m,
    comments: m.comments.map((c) =>
      c.id === commentId && !c.reports.includes(visitorId) ? { ...c, reports: [...c.reports, visitorId] } : c
    ),
  })));
}

export function deleteComment({ id, commentId, visitorId }) {
  const mem = memories.find((m) => m.id === id);
  const c = mem && mem.comments.find((x) => x.id === commentId);
  if (!c || c.authorId !== visitorId) throw new PermissionError("Você só pode excluir o seu comentário.");
  commit(mapOne(id, (m) => ({ ...m, comments: m.comments.filter((x) => x.id !== commentId) })));
}

/* Demo helpers — console only (window.__lelePanDev.seedMemories()). Text-led
   placeholders clearly marked demo; never shown unless someone seeds them. */
export function seedDemoMemories() {
  const now = Date.now();
  const base = (i, name, caption, context) => ({
    id: uid("m"),
    authorId: `demo_${i}`,
    authorName: name,
    caption,
    context,
    mediaType: null,
    aspect: 1,
    createdAt: now - i * 3600_000,
    edited: false,
    demo: true,
    likes: [],
    reports: [],
    comments: [],
  });
  commit([
    base(1, "Exemplo A", "Texto de exemplo para a demonstração do mural.", "Exemplo"),
    base(2, "Exemplo B", "Outra memória de exemplo — troque por conteúdo real.", "Exemplo"),
    base(3, "Exemplo C", "Mais uma, só para mostrar a variação do mural.", ""),
    ...memories,
  ]);
}
export function clearAllMemories() {
  memories.forEach((m) => delBlob(m.id));
  urlCache.clear();
  commit([]);
}
