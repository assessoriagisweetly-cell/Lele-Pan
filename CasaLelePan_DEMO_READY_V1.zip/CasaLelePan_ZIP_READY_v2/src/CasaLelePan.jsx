import React, { useState, useRef, useEffect, useLayoutEffect, useMemo, useCallback } from "react";
import { Desde1988Page, LegalPage, MemoryComposer, DESDE_STYLES } from "./Desde1988.jsx";
import { getVisitorId, seedDemoMemories, clearAllMemories } from "./memories.js";

/* ============================================================================
   DATA
   ============================================================================ */

const PRODUCTS = [
  {
    id: "coxinha-grande",
    name: "Coxinha Grande",
    tag: "QUERIDINHO",
    description: "Crocante por fora. Cremosa por dentro.",
    detailDescription:
      "Massa fina, casquinha dourada e um recheio cremoso de frango. A coxinha que faz gente atravessar a rua.",
    price: 8.9,
    tone: "fried",
    ratio: "4/5",
    image: null, // ex.: "/media/produtos/coxinha-grande.jpg"
    video: null, // ex.: "/media/produtos/coxinha-grande.mp4"
  },
  {
    id: "cafe-expresso",
    name: "Café Expresso",
    description: "Torra escura. Cheiro que enche a loja.",
    detailDescription:
      "Extraído na hora, curto e encorpado. O tipo de café que já faz parte da sua manhã.",
    price: 6.9,
    tone: "coffee",
    ratio: "4/5",
    image: null,
    video: null,
  },
  {
    id: "pizza-pedaco",
    name: "Pizza Pedaço",
    description: "Massa fina. Borda que estala.",
    detailDescription:
      "Fatia generosa, assada em forno quente, com molho de tomate e queijo derretendo até a borda.",
    price: 9.5,
    tone: "tomato",
    ratio: "4/5",
    image: null,
    video: null,
  },
  {
    id: "carolina-doce-de-leite",
    name: "Carolina Doce de Leite",
    description: "Leve por fora. Doce de leite puro dentro.",
    detailDescription:
      "Massa leve, quase aerada, recheada com doce de leite até a última mordida.",
    price: 7.5,
    tone: "caramel",
    ratio: "4/5",
    image: null,
    video: null,
  },
  {
    id: "mini-salgados",
    name: "Mini Salgados",
    description: "Para dividir. Ou não.",
    detailDescription:
      "Seleção de mini salgados fritos e assados, prontos pra mesa — ou pra comer no caminho de casa.",
    price: 6.9,
    tone: "mixed",
    ratio: "4/5",
    image: null,
    video: null,
  },
  {
    id: "trio-maravilha",
    name: "Trio Maravilha",
    description: "Três clássicos. Uma bandeja só sua.",
    detailDescription:
      "Coxinha, pão de queijo e mini pastel juntos numa bandeja. Pra quem não quer escolher só um.",
    price: 28.5,
    tone: "combo",
    ratio: "4/5",
    image: null,
    video: null,
  },
];

// Hero and heritage media — same swap-in pattern as products above.
const HERO_MEDIA = { src: null, video: null }; // ex.: video: "/media/hero/capa.mp4"
const HERITAGE_MEDIA = { src: null, video: null }; // ex.: src: "/media/heritage/fachada-1988.jpg"

const WHATSAPP_PHONE = "551122563157"; // official Lele Pan WhatsApp: +55 11 2256-3157

/* ----------------------------------------------------------------------------
   CHECKOUT — store info, hours, delivery fee config, order numbers
   ---------------------------------------------------------------------------- */

const STORE = {
  name: "Lele Pan",
  addressLines: ["R. Joaquim Afonso de Souza, 486", "Casa Verde — São Paulo — SP", "02543-000"],
  address: "R. Joaquim Afonso de Souza, 486, Casa Verde, São Paulo - SP, 02543-000", // used for embed + directions
  phoneDisplay: "+55 11 2256-3157",
  phoneDigits: "551122563157", // official phone / WhatsApp digits
  mapsUrl: "https://maps.app.goo.gl/17YFRjqcZxg3P5Bz5", // official Google Maps destination
};

// Same hours every day per the business's current information.
const OPENING_HOURS = { openHour: 6, openMinute: 0, closeHour: 21, closeMinute: 50 };
const WEEK_HOURS = [
  { day: "Segunda-feira", hours: "06:00–21:50" },
  { day: "Terça-feira", hours: "06:00–21:50" },
  { day: "Quarta-feira", hours: "06:00–21:50" },
  { day: "Quinta-feira", hours: "06:00–21:50" },
  { day: "Sexta-feira", hours: "06:00–21:50" },
  { day: "Sábado", hours: "06:00–21:50" },
  { day: "Domingo", hours: "06:00–21:50" },
];
const WEEKDAY_LABELS = [
  "Domingo", "Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sábado",
];

function isOpenNow(now = new Date()) {
  const minutesNow = now.getHours() * 60 + now.getMinutes();
  const openMin = OPENING_HOURS.openHour * 60 + OPENING_HOURS.openMinute;
  const closeMin = OPENING_HOURS.closeHour * 60 + OPENING_HOURS.closeMinute;
  return minutesNow >= openMin && minutesNow < closeMin;
}

function formatHHMM(date) {
  return `${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`;
}

// "Agora" (if open) plus upcoming half-hour pickup slots, respecting closing
// time. If the bakery is currently closed, offers slots from next opening.
function getPickupSlots(now = new Date()) {
  const slots = [];
  const open = isOpenNow(now);
  if (open) slots.push("Agora");

  const close = new Date(now);
  close.setHours(OPENING_HOURS.closeHour, OPENING_HOURS.closeMinute, 0, 0);

  let cursor = new Date(now);
  if (!open && now.getHours() * 60 + now.getMinutes() >= OPENING_HOURS.closeHour * 60 + OPENING_HOURS.closeMinute) {
    // after closing — next slots are tomorrow morning
    cursor.setDate(cursor.getDate() + 1);
    cursor.setHours(OPENING_HOURS.openHour, OPENING_HOURS.openMinute, 0, 0);
    close.setDate(close.getDate() + 1);
  } else if (!open) {
    // before opening today
    cursor.setHours(OPENING_HOURS.openHour, OPENING_HOURS.openMinute, 0, 0);
  } else {
    // at least ~20 min prep time, rounded up to the next half hour
    cursor = new Date(now.getTime() + 20 * 60000);
    const mins = cursor.getMinutes();
    cursor.setMinutes(mins <= 30 ? 30 : 0, 0, 0);
    if (mins > 30) cursor.setHours(cursor.getHours() + 1);
  }

  while (slots.length < 4 && cursor <= close) {
    slots.push(formatHHMM(cursor));
    cursor = new Date(cursor.getTime() + 30 * 60000);
  }
  return slots;
}

// Delivery fee configuration — the business can change this later without
// touching any UI or component code. mode: "fixed" | "manual" | "by_distance".
// "manual" (no confirmed fee yet) is the honest default until Lele Pan sets one.
const DELIVERY_FEE_CONFIG = { mode: "manual", fee: null };

function getDeliveryFee() {
  if (DELIVERY_FEE_CONFIG.mode === "fixed" && typeof DELIVERY_FEE_CONFIG.fee === "number") {
    return DELIVERY_FEE_CONFIG.fee;
  }
  return null; // null = not yet configured
}

// Prototype-only order number generator — replace with a real sequential
// order id from the backend once orders are actually persisted there.
function generateOrderNumber() {
  return 1000 + Math.floor(Math.random() * 900);
}

/* ----------------------------------------------------------------------------
   STORAGE — thin wrappers around window.storage that can NEVER throw, not
   even synchronously. Persistence is always best-effort: if it fails for any
   reason, the app must keep working exactly as if storage didn't exist. This
   matters because window.storage isn't present in every environment this
   code runs in, and a synchronous throw here would otherwise interrupt
   whatever synchronous code called it (e.g. profile save blocking Círculo
   from opening).
   ---------------------------------------------------------------------------- */
function hasLocal() {
  try {
    return typeof window !== "undefined" && !!window.localStorage;
  } catch (e) {
    return false;
  }
}
function storageAvailable() {
  try {
    return typeof window !== "undefined" && !!window.storage && typeof window.storage.set === "function";
  } catch (e) {
    return false;
  }
}
function safeStorageSet(key, value) {
  try {
    if (hasLocal()) window.localStorage.setItem(key, value);
  } catch (e) {
    // best-effort only
  }
  try {
    if (storageAvailable()) window.storage.set(key, value, false).catch(() => {});
  } catch (e) {
    // best-effort only
  }
}
function safeStorageDelete(key) {
  try {
    if (hasLocal()) window.localStorage.removeItem(key);
  } catch (e) {
    // best-effort only
  }
  try {
    if (storageAvailable()) window.storage.delete(key, false).catch(() => {});
  } catch (e) {
    // best-effort only
  }
}
// Synchronous read (localStorage) — lets state initialise with the saved value
// on the very first render, so a returning member never sees the form flash.
function safeStorageGetSync(key) {
  try {
    if (hasLocal()) return window.localStorage.getItem(key);
  } catch (e) {
    // ignore
  }
  return null;
}
async function safeStorageGet(key) {
  const local = safeStorageGetSync(key);
  if (local != null) return { value: local };
  try {
    if (storageAvailable()) return await window.storage.get(key, false);
  } catch (e) {
    // key missing or storage unavailable — caller treats this as "no value"
  }
  return null;
}

// Only the first character is capitalised: "guedalia" -> "Guedalia".
function formatName(raw) {
  const t = (raw || "").trim().replace(/\s+/g, " ");
  return t ? t.charAt(0).toUpperCase() + t.slice(1) : "";
}
function readProfileSync() {
  try {
    const raw = safeStorageGetSync("circulo:profile");
    if (!raw) return null;
    const p = JSON.parse(raw);
    if (!p || typeof p !== "object") return null;
    return { ...p, onboardingCompleted: true }; // any saved profile = onboarding already done
  } catch (e) {
    return null;
  }
}
function readNumberSync(key) {
  const n = parseInt(safeStorageGetSync(key), 10);
  return Number.isNaN(n) ? 0 : n;
}
function readFavoritesSync() {
  try {
    const p = JSON.parse(safeStorageGetSync("lelepan:favorites") || "{}");
    return p && typeof p === "object" ? p : {};
  } catch (e) {
    return {};
  }
}


/* ----------------------------------------------------------------------------
   CÍRCULO LELE — mock/prototype data
   ----------------------------------------------------------------------------
   None of this is real backend data. There is no order history, benefits
   engine, or surprise service behind this yet — "favorite" is the only piece
   that reflects a real user action (the heart toggle on product cards).

   RECENT_ORDERS and the Mimos/Surpresa data below are illustrative
   placeholders so the screen has something believable to show. Reward
   thresholds and surprise copy are conceptual and have not been approved
   as a real program. When a backend exists, swap this file's reads for
   real queries — the components below don't need to change, only where
   this data comes from.
   ---------------------------------------------------------------------------- */

const RECENT_ORDERS = [
  { id: "order-1", dateLabel: "Hoje", items: [{ id: "coxinha-grande", qty: 1 }, { id: "cafe-expresso", qty: 1 }] },
  { id: "order-2", dateLabel: "terça-feira", items: [{ id: "trio-maravilha", qty: 1 }] },
  { id: "order-3", dateLabel: "domingo", items: [{ id: "mini-salgados", qty: 1 }, { id: "cafe-expresso", qty: 1 }] },
];

// Conceptual only — not an approved loyalty program. Thresholds and rewards
// are prototype examples; the business can change this list at any time.
// "productId" links a reward to a real menu item so redemption can actually
// add it to the cart — rewards without a matching product only show as text.
const MIMOS_BALANCE = 62; // mock current balance — replace with real account balance
const MIMOS_VISITS_THIS_MONTH = 3; // mock — replace with real visit count

const MIMOS_REWARDS = [
  { id: "mimo-cafe", cost: 25, name: "Café Expresso", productId: "cafe-expresso" },
  { id: "mimo-salgados", cost: 50, name: "Mini Salgados", productId: "mini-salgados" },
  { id: "mimo-coxinha", cost: 80, name: "Coxinha Grande", productId: "coxinha-grande", badge: "MIMO DA SEMANA" },
  { id: "mimo-trio", cost: 120, name: "Trio Maravilha", productId: "trio-maravilha" },
];

// Rotating "surprise" events — which one shows is mock/deterministic-by-day
// here, standing in for whatever a real backend would decide per customer.
// Not every event carries a commercial "bonus" line — scarcity/incentive
// framing is meant to feel occasional, not attached to every single one.
const SURPRESA_EVENTS = [
  { badge: "MIMO DA SEMANA", message: "Hoje o café é por nossa conta.", bonus: "+10 Mimos em pedidos até as 11h." },
  { badge: "ESPECIAL PARA VOCÊ", message: "Seu favorito está valendo Mimo em dobro hoje.", bonus: null },
  { badge: "VOCÊ VIU PRIMEIRO", message: "Tem novidade chegando — você vê antes de todo mundo.", bonus: null },
  { badge: "SÓ NO FIM DE SEMANA", message: "Este fim de semana tem algo especial para o Círculo.", bonus: "+15 Mimos em pedidos com mais de um item." },
  { badge: "GUARDADO PARA VOCÊ", message: "Tem um mimo guardado para você.", bonus: null },
];

function findNextReward(balance) {
  return [...MIMOS_REWARDS].sort((a, b) => a.cost - b.cost).find((r) => r.cost > balance) || null;
}

function resolveOrderItems(order) {
  return order.items
    .map(({ id, qty }) => {
      const product = PRODUCTS.find((p) => p.id === id);
      return product ? { ...product, qty } : null;
    })
    .filter(Boolean);
}

function orderLabel(resolvedItems) {
  return resolvedItems.map((i) => (i.qty > 1 ? `${i.qty}x ${i.name}` : i.name)).join(" + ");
}

function orderTotal(resolvedItems) {
  return resolvedItems.reduce((sum, i) => sum + i.price * i.qty, 0);
}


/* ============================================================================
   UTILITIES
   ============================================================================ */

function formatBRL(value) {
  const fixed = value.toFixed(2);
  const [intPart, decPart] = fixed.split(".");
  const withThousands = intPart.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  return `R$ ${withThousands},${decPart}`;
}

// Same formatting, no space after "R$" — matches the exact WhatsApp message
// format specified for checkout, kept separate so it never touches how
// prices are displayed anywhere else in the UI.
function formatBRLCompact(value) {
  return formatBRL(value).replace("R$ ", "R$");
}

/* ----------------------------------------------------------------------------
   BRAZILIAN DATE INPUT — DD/MM/AAAA only. Deliberately not using
   <input type="date">: that control renders in the browser/OS locale format
   (e.g. MM/DD/YYYY for an en-US environment) regardless of page language, so
   it can silently show or accept the wrong format for a Brazilian audience.
   A masked text field keeps the format unambiguous everywhere.
   ---------------------------------------------------------------------------- */

// Strips non-digits and re-inserts "/" as the user types: "03092010" -> "03/09/2010".
function maskDateBR(raw) {
  const digits = raw.replace(/\D/g, "").slice(0, 8);
  const day = digits.slice(0, 2);
  const month = digits.slice(2, 4);
  const year = digits.slice(4, 8);
  let out = day;
  if (digits.length > 2) out += "/" + month;
  if (digits.length > 4) out += "/" + year;
  return out;
}

// Validates a complete DD/MM/AAAA string against real calendar rules
// (correct days-per-month, leap years) and returns the parsed parts plus an
// ISO (YYYY-MM-DD) form for consistent backend-safe storage. Returns null
// for anything incomplete or invalid — never guesses or swaps day/month.
function parseDateBR(value) {
  const match = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(value || "");
  if (!match) return null;
  const day = parseInt(match[1], 10);
  const month = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  if (month < 1 || month > 12) return null;
  const daysInMonth = new Date(year, month, 0).getDate();
  if (day < 1 || day > daysInMonth) return null;
  if (year < 1900 || year > new Date().getFullYear()) return null;
  const iso = `${String(year).padStart(4, "0")}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
  return { day, month, year, iso };
}

// Builds the WhatsApp order message in the exact pickup/delivery formats
// specified by the business — item lines as "Nome × qty", then a totals
// block that differs by receiving method, closing with a friendly line.
function buildWhatsAppMessage({ orderNumber, items, subtotal, method, pickupTime, address, deliveryFee }) {
  const lines = ["Oi, Lele Pan! 💛", "Quero fazer esse pedido:", "", `Pedido #${orderNumber}`, ""];
  items.forEach((item) => lines.push(`${item.name} × ${item.qty}`));
  lines.push("");

  if (method === "retirar") {
    lines.push(`Total: ${formatBRLCompact(subtotal)}`);
    lines.push("");
    lines.push(`Retirada: ${pickupTime}`);
    lines.push("");
    lines.push("Vou retirar aí na Lele Pan 😊");
  } else {
    lines.push(`Subtotal: ${formatBRLCompact(subtotal)}`);
    lines.push(deliveryFee == null ? "Entrega: a combinar" : `Entrega: ${formatBRLCompact(deliveryFee)}`);
    lines.push(deliveryFee == null ? `Total: ${formatBRLCompact(subtotal)} + entrega a combinar` : `Total: ${formatBRLCompact(subtotal + deliveryFee)}`);
    lines.push("");
    lines.push("Endereço:");
    lines.push(address && address.trim() ? address.trim() : "(endereço não informado)");
  }

  return lines.join("\n");
}

function whatsappUrl(message) {
  return `https://wa.me/${WHATSAPP_PHONE}?text=${encodeURIComponent(message)}`;
}

function usePrefersReducedMotion() {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReduced(mq.matches);
    const handler = (e) => setReduced(e.matches);
    mq.addEventListener ? mq.addEventListener("change", handler) : mq.addListener(handler);
    return () => {
      mq.removeEventListener
        ? mq.removeEventListener("change", handler)
        : mq.removeListener(handler);
    };
  }, []);
  return reduced;
}

// Triggers once when the ref'd element first enters the viewport — used for
// single, intentional entrance moments (not a generic scroll-fade utility).
function useRevealOnce(ref, threshold = 0.25) {
  const [revealed, setRevealed] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setRevealed(true);
            observer.disconnect();
          }
        });
      },
      { threshold }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [ref, threshold]);
  return revealed;
}

/* ============================================================================
   ICONS — single consistent geometric outline family, 1.5–2px stroke
   ============================================================================ */

function IconBase({ children, size = 20, strokeWidth = 1.75, className = "", ...rest }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
      {...rest}
    >
      {children}
    </svg>
  );
}

const IconArrowRight = (p) => (
  <IconBase {...p}>
    <path d="M4 12h16M14 6l6 6-6 6" />
  </IconBase>
);
const IconArrowLeft = (p) => (
  <IconBase {...p}>
    <path d="M20 12H4M10 6l-6 6 6 6" />
  </IconBase>
);
const IconArrowDown = (p) => (
  <IconBase {...p}>
    <path d="M12 4v16M6 14l6 6 6-6" />
  </IconBase>
);
const IconPlus = (p) => (
  <IconBase {...p}>
    <path d="M12 5v14M5 12h14" />
  </IconBase>
);
const IconMinus = (p) => (
  <IconBase {...p}>
    <path d="M5 12h14" />
  </IconBase>
);
const IconClose = (p) => (
  <IconBase {...p}>
    <path d="M6 6l12 12M18 6L6 18" />
  </IconBase>
);
const IconCheck = (p) => (
  <IconBase {...p}>
    <path d="M4 12.5l5 5L20 6" />
  </IconBase>
);
const IconBag = (p) => (
  <IconBase {...p}>
    <path d="M6.5 8h11l1 12.2H5.5L6.5 8z" />
    <path d="M9 8V6.6A3 3 0 0 1 12 3.6a3 3 0 0 1 3 3V8" />
  </IconBase>
);
const IconHeart = ({ filled, ...p }) => (
  <IconBase {...p}>
    <path
      d="M12 20s-7.1-4.35-9.6-8.6C.7 7.7 2.4 4.3 6 4.3c2 0 3.4 1.1 4 2.4.6-1.3 2-2.4 4-2.4 3.6 0 5.3 3.4 3.6 7.1C19.1 15.65 12 20 12 20z"
      fill={filled ? "currentColor" : "none"}
    />
  </IconBase>
);
const IconChat = (p) => (
  <IconBase {...p}>
    <path d="M4.5 19.5l1.1-3.3a7.7 7.7 0 1 1 3 2.9L4.5 19.5z" />
  </IconBase>
);
const IconPin = (p) => (
  <IconBase {...p}>
    <path d="M12 21s7-6.2 7-11.3A7 7 0 1 0 5 9.7C5 14.8 12 21 12 21z" />
    <circle cx="12" cy="9.6" r="2.1" />
  </IconBase>
);
const IconCircle = (p) => (
  <IconBase {...p}>
    <circle cx="12" cy="12" r="7.6" />
    <circle cx="12" cy="12" r="2.6" />
  </IconBase>
);
const IconFrame = (p) => (
  <IconBase {...p}>
    <rect x="3.5" y="4.5" width="17" height="15" rx="1.5" />
    <circle cx="9" cy="10" r="1.6" />
    <path d="M4 17l5-4.5 3.5 3L17 11l3 3.5" />
  </IconBase>
);
const IconPlay = (p) => (
  <IconBase {...p}>
    <circle cx="12" cy="12" r="8.2" />
    <path d="M10.2 8.8l5.4 3.2-5.4 3.2V8.8z" />
  </IconBase>
);
const IconGift = (p) => (
  <IconBase {...p}>
    <rect x="4" y="10" width="16" height="9.5" rx="1" />
    <path d="M4 10h16M12 10v9.5" />
    <path d="M12 10C10.5 10 8.7 9.2 8.7 7.4 8.7 6 9.8 5 11 5.3c1 .3 2 1.6 3 2.9C13 6.9 14 5.6 15 5.3c1.2-.3 2.3.7 2.3 2.1 0 1.8-1.8 2.6-3.3 2.6" />
  </IconBase>
);

/* ============================================================================
   MEDIA SLOT
   ----------------------------------------------------------------------------
   Every photo/video in this build is a placeholder. GUE places all final
   photography and video manually — this component is the single seam where
   that happens:

     • Product photo:  <MediaSlot tone="fried" src="/media/coxinha.jpg" />
     • Product video:  <MediaSlot tone="fried" videoSrc="/media/coxinha.mp4" />
     • Nothing yet:    <MediaSlot tone="fried" label="Foto do produto" />
                        (renders the warm gradient placeholder + label below)

   The wrapping element's size, aspect-ratio, border-radius, and object-fit
   are all controlled by CSS on the *container* (product-card__media,
   detail__media, hero__media, etc.) — never by this component. That means
   dropping in `src` or `videoSrc` swaps the visual content without touching
   layout, crop, spacing, or the shared-element transition, which measures
   and animates this same container regardless of what is inside it.
   ============================================================================ */

const MediaSlot = React.forwardRef(function MediaSlot(
  { tone = "fried", src, videoSrc, poster, alt = "", label, compact = false, className = "", style = {} },
  ref
) {
  const hasVideo = !!videoSrc;
  const hasImage = !!src && !hasVideo;
  const isPlaceholder = !hasVideo && !hasImage;

  return (
    <div
      ref={ref}
      className={`media-slot ${isPlaceholder ? `media-slot--${tone}` : ""} ${className}`}
      style={style}
    >
      {hasVideo && (
        <video className="media-slot__media" src={videoSrc} poster={poster} autoPlay muted loop playsInline />
      )}
      {hasImage && <img className="media-slot__media" src={src} alt={alt} />}
      {isPlaceholder && !compact && label && (
        <span className="media-slot__label">
          <IconFrame size={13} strokeWidth={1.6} />
          {label}
        </span>
      )}
      {isPlaceholder && compact && (
        <span className="media-slot__mark">
          <IconFrame size={14} strokeWidth={1.6} />
        </span>
      )}
    </div>
  );
});

/* ============================================================================
   PRIMITIVES
   ============================================================================ */

function PrimaryButton({ children, onClick, state = "default", className = "", type = "button", ...rest }) {
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={state === "disabled"}
      className={`btn-primary btn-primary--${state} ${className}`}
      {...rest}
    >
      {children}
    </button>
  );
}

function EditorialLink({ children, onClick, direction = "right", className = "", as = "button", href, ...rest }) {
  const content = (
    <>
      <span>{children}</span>
      {direction === "right" && <IconArrowRight size={16} strokeWidth={1.6} />}
      {direction === "left" && <IconArrowLeft size={16} strokeWidth={1.6} />}
      {direction === "down" && <IconArrowDown size={16} strokeWidth={1.6} />}
    </>
  );
  if (as === "a") {
    return (
      <a href={href} onClick={onClick} className={`editorial-link ${className}`} {...rest}>
        {content}
      </a>
    );
  }
  return (
    <button type="button" onClick={onClick} className={`editorial-link ${className}`} {...rest}>
      {content}
    </button>
  );
}

/* ============================================================================
   ADD CONTROL — quick add on product cards
   ============================================================================ */

function QuickAddControl({ onAdd }) {
  const [justAdded, setJustAdded] = useState(false);
  const timeoutRef = useRef(null);

  const handleClick = (e) => {
    e.stopPropagation();
    onAdd();
    setJustAdded(true);
    if (timeoutRef.current) window.clearTimeout(timeoutRef.current);
    timeoutRef.current = window.setTimeout(() => setJustAdded(false), 900);
  };

  useEffect(() => () => timeoutRef.current && window.clearTimeout(timeoutRef.current), []);

  return (
    <button
      type="button"
      className={`add-control ${justAdded ? "add-control--added" : ""}`}
      onClick={handleClick}
      aria-label={justAdded ? "Adicionado ao pedido" : "Adicionar ao pedido"}
    >
      {justAdded ? (
        <>
          <span>ADICIONADO</span>
          <IconCheck size={15} strokeWidth={1.8} />
        </>
      ) : (
        <>
          <span>ADICIONAR</span>
          <IconPlus size={15} strokeWidth={1.8} />
        </>
      )}
    </button>
  );
}

function Stepper({ qty, onChange, min = 1, size = "m" }) {
  return (
    <div className={`stepper stepper--${size}`}>
      <button
        type="button"
        className="stepper__btn"
        onClick={() => onChange(Math.max(min - 1, qty - 1))}
        aria-label="Diminuir quantidade"
      >
        <IconMinus size={14} strokeWidth={1.8} />
      </button>
      <span className="stepper__value" aria-live="polite">
        {qty}
      </span>
      <button
        type="button"
        className="stepper__btn"
        onClick={() => onChange(qty + 1)}
        aria-label="Aumentar quantidade"
      >
        <IconPlus size={14} strokeWidth={1.8} />
      </button>
    </div>
  );
}

/* ============================================================================
   NAVIGATION — desktop
   ============================================================================ */

function Nav({ cartCount, onOpenCart, onNavigate, active }) {
  const [condensed, setCondensed] = useState(false);

  useEffect(() => {
    const onScroll = () => setCondensed(window.scrollY > 28);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const links = [
    { key: "casa", label: "CASA" },
    { key: "cardapio", label: "CARDÁPIO" },
    { key: "circulo", label: "CÍRCULO" },
    { key: "desde", label: "DESDE 1988" },
  ];

  return (
    <header className={`nav ${condensed ? "nav--condensed" : ""}`}>
      <div className="nav__inner">
        <button type="button" className="nav__logo" onClick={() => onNavigate("casa")}>
          Lele Pan
        </button>
        <nav className="nav__links" aria-label="Navegação principal">
          {links.map((l) => (
            <button
              key={l.key}
              type="button"
              className={`nav-link ${active === l.key ? "nav-link--active" : ""}`}
              onClick={() => onNavigate(l.key)}
            >
              {l.label}
            </button>
          ))}
        </nav>
        <button
          type="button"
          className="nav__bag"
          onClick={onOpenCart}
          aria-label={`Sacola, ${cartCount} ${cartCount === 1 ? "item" : "itens"}`}
        >
          <IconBag size={21} strokeWidth={1.6} />
          {cartCount > 0 && <span className="nav__bag-badge">{cartCount}</span>}
        </button>
      </div>
    </header>
  );
}

/* ============================================================================
   NAVIGATION — mobile bottom bar
   ============================================================================ */

function MobileNav({ cartCount, onOpenCart, onNavigate, active }) {
  const items = [
    { key: "casa", label: "Casa", Icon: IconPin },
    { key: "cardapio", label: "Cardápio", Icon: IconArrowDown },
    { key: "circulo", label: "Círculo", Icon: IconCircle },
    { key: "desde", label: "1988", Icon: IconFrame },
  ];
  return (
    <nav className="mobile-nav" aria-label="Navegação">
      {items.map(({ key, label, Icon }) => (
        <button
          key={key}
          type="button"
          className={`mobile-nav__item ${active === key ? "mobile-nav__item--active" : ""}`}
          onClick={() => onNavigate(key)}
        >
          <Icon size={20} strokeWidth={1.6} />
          <span>{label}</span>
        </button>
      ))}
      <button type="button" className="mobile-nav__item" onClick={onOpenCart}>
        <span className="mobile-nav__bag-wrap">
          <IconBag size={20} strokeWidth={1.6} />
          {cartCount > 0 && <span className="mobile-nav__badge">{cartCount}</span>}
        </span>
        <span>Sacola</span>
      </button>
    </nav>
  );
}

/* ============================================================================
   HERO — CASA
   ============================================================================ */

function Hero({ onCTA, sectionRef }) {
  const [ready, setReady] = useState(false);
  const reduced = usePrefersReducedMotion();

  useEffect(() => {
    if (reduced) {
      setReady(true);
      return;
    }
    const id = requestAnimationFrame(() => window.setTimeout(() => setReady(true), 60));
    return () => cancelAnimationFrame(id);
  }, [reduced]);

  return (
    <section id="casa" ref={sectionRef} className={`hero ${ready ? "hero--ready" : ""}`}>
      <MediaSlot tone="hero" src={HERO_MEDIA.src} videoSrc={HERO_MEDIA.video} label="Foto ou vídeo de capa" className="hero__media" />
      <div className="hero__scrim" />
      <div className="hero__content">
        <h1 className="hero__headline">
          <span className="hero__line">PÃO</span>
          <span className="hero__line">QUENTINHO</span>
          <span className="hero__line">TODA HORA.</span>
        </h1>
        <p className="hero__sub">Tem coisa que você não precisa pensar duas vezes.</p>
        <div className="hero__cta">
          <PrimaryButton onClick={onCTA}>
            VER O QUE SAIU <IconArrowRight size={16} strokeWidth={1.8} />
          </PrimaryButton>
        </div>
      </div>
    </section>
  );
}

/* ============================================================================
   PRODUCT CARD
   ============================================================================ */

function ProductCard({ product, qty, isFav, onToggleFav, onQuickAdd, onOpenDetail }) {
  const imgRef = useRef(null);

  const handleOpen = () => {
    const rect = imgRef.current ? imgRef.current.getBoundingClientRect() : null;
    onOpenDetail(product, rect);
  };

  return (
    <article className="product-card">
      <div className="product-card__media" onClick={handleOpen} role="button" tabIndex={0}
        onKeyDown={(e) => { if (e.key === "Enter") handleOpen(); }}
        aria-label={`Ver ${product.name}`}
      >
        <MediaSlot
          tone={product.tone}
          src={product.image}
          videoSrc={product.video}
          alt={product.name}
          label="Foto do produto"
          ref={imgRef}
          className="product-card__image"
        />
        {product.tag && <span className="tag">{product.tag}</span>}
        <button
          type="button"
          className={`fav-btn ${isFav ? "fav-btn--active" : ""}`}
          onClick={(e) => {
            e.stopPropagation();
            onToggleFav(product.id);
          }}
          aria-label={isFav ? "Remover dos favoritos" : "Adicionar aos favoritos"}
        >
          <IconHeart filled={isFav} size={18} strokeWidth={1.7} />
        </button>
      </div>
      <div className="product-card__info">
        <h3 className="product-card__name" onClick={handleOpen}>{product.name}</h3>
        <p className="product-card__desc">{product.description}</p>
        <div className="product-card__footer">
          <span className="product-card__price">{formatBRL(product.price)}</span>
          {qty > 0 ? (
            <Stepper qty={qty} onChange={(n) => onQuickAdd(product, n - qty)} size="s" />
          ) : (
            <QuickAddControl onAdd={() => onQuickAdd(product, 1)} />
          )}
        </div>
      </div>
    </article>
  );
}

/* ============================================================================
   SAIU DO FORNO
   ============================================================================ */

function FreshSection({ sectionRef, products, cart, favorites, onToggleFav, onQuickAdd, onOpenDetail }) {
  return (
    <section id="cardapio" ref={sectionRef} className="fresh">
      <div className="container">
        <div className="section-head">
          <h2 className="section-head__title">
            SAIU DO FORNO
            <span className="section-head__accent">Agora.</span>
          </h2>
        </div>
        <div className="product-grid">
          {products.map((p) => (
            <ProductCard
              key={p.id}
              product={p}
              qty={cart[p.id] || 0}
              isFav={!!favorites[p.id]}
              onToggleFav={onToggleFav}
              onQuickAdd={onQuickAdd}
              onOpenDetail={onOpenDetail}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

/* ============================================================================
   PRODUCT DETAIL — shared-element (FLIP) transition from card image
   ============================================================================ */

function ProductDetail({ product, sourceRect, qty, isFav, onToggleFav, onAdd, onClose }) {
  const imgRef = useRef(null);
  const overlayRef = useRef(null);
  const [revealed, setRevealed] = useState(false);
  const [localQty, setLocalQty] = useState(1);
  const [justAdded, setJustAdded] = useState(false);
  const reduced = usePrefersReducedMotion();
  const addedTimeoutRef = useRef(null);

  // opening FLIP
  useLayoutEffect(() => {
    const el = imgRef.current;
    if (!el) return;
    if (!sourceRect || reduced) {
      setRevealed(true);
      return;
    }
    const targetRect = el.getBoundingClientRect();
    const dx = sourceRect.left - targetRect.left;
    const dy = sourceRect.top - targetRect.top;
    const sx = sourceRect.width / targetRect.width;
    const sy = sourceRect.height / targetRect.height;
    el.style.transition = "none";
    el.style.transformOrigin = "top left";
    el.style.transform = `translate(${dx}px, ${dy}px) scale(${sx}, ${sy})`;
    // eslint-disable-next-line no-unused-expressions
    el.offsetWidth;
    requestAnimationFrame(() => {
      el.style.transition = "transform 480ms cubic-bezier(0.22, 1, 0.36, 1)";
      el.style.transform = "translate(0px, 0px) scale(1, 1)";
    });
    const revealId = window.setTimeout(() => setRevealed(true), 160);
    return () => window.clearTimeout(revealId);
  }, [sourceRect, reduced]);

  useEffect(() => {
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = "";
    };
  }, []);

  useEffect(() => {
    const onKey = (e) => {
      if (e.key === "Escape") handleClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => () => addedTimeoutRef.current && window.clearTimeout(addedTimeoutRef.current), []);

  function handleClose() {
    const el = imgRef.current;
    const overlayEl = overlayRef.current;
    const duration = reduced ? 0 : 420;
    if (el && sourceRect && !reduced) {
      const targetRect = el.getBoundingClientRect();
      const dx = sourceRect.left - targetRect.left;
      const dy = sourceRect.top - targetRect.top;
      const sx = sourceRect.width / targetRect.width;
      const sy = sourceRect.height / targetRect.height;
      el.style.transition = `transform ${duration}ms cubic-bezier(0.22, 1, 0.36, 1)`;
      el.style.transform = `translate(${dx}px, ${dy}px) scale(${sx}, ${sy})`;
    }
    if (overlayEl) {
      overlayEl.style.transition = `opacity ${duration}ms ease`;
      overlayEl.style.opacity = "0";
    }
    setRevealed(false);
    window.setTimeout(() => onClose(), duration);
  }

  function handleAdd() {
    onAdd(product, localQty);
    setJustAdded(true);
    setLocalQty(1);
    if (addedTimeoutRef.current) window.clearTimeout(addedTimeoutRef.current);
    addedTimeoutRef.current = window.setTimeout(() => setJustAdded(false), 1100);
  }

  return (
    <div className="detail-overlay" ref={overlayRef} role="dialog" aria-modal="true" aria-label={product.name}>
      <div className="detail-overlay__scrim" onClick={handleClose} />
      <div className="detail">
        <button type="button" className="detail__close" onClick={handleClose} aria-label="Fechar">
          <IconClose size={20} strokeWidth={1.6} />
        </button>
        <div className="detail__media">
          <MediaSlot
            tone={product.tone}
            src={product.image}
            videoSrc={product.video}
            alt={product.name}
            label="Foto do produto"
            ref={imgRef}
            className="detail__image"
          />
        </div>
        <div className={`detail__body ${revealed ? "detail__body--revealed" : ""}`}>
          <EditorialLink direction="left" onClick={handleClose} className="detail__back">
            VOLTAR
          </EditorialLink>
          {product.tag && <span className="tag detail__tag">{product.tag}</span>}
          <h2 className="detail__name">{product.name}</h2>
          <p className="detail__desc">{product.detailDescription}</p>
          <div className="detail__row">
            <span className="detail__price">{formatBRL(product.price)}</span>
            <button
              type="button"
              className={`fav-btn fav-btn--inline ${isFav ? "fav-btn--active" : ""}`}
              onClick={() => onToggleFav(product.id)}
              aria-label={isFav ? "Remover dos favoritos" : "Adicionar aos favoritos"}
            >
              <IconHeart filled={isFav} size={19} strokeWidth={1.7} />
            </button>
          </div>
          <div className="detail__actions">
            <Stepper qty={localQty} onChange={setLocalQty} size="m" />
            <PrimaryButton onClick={handleAdd} state={justAdded ? "added" : "default"} className="detail__add">
              {justAdded ? (
                <>ADICIONADO <IconCheck size={16} strokeWidth={1.8} /></>
              ) : (
                <>ADICIONAR <IconPlus size={16} strokeWidth={1.8} /></>
              )}
            </PrimaryButton>
          </div>
          {qty > 0 && <p className="detail__in-bag">{qty} {qty === 1 ? "unidade" : "unidades"} na sua sacola</p>}
        </div>
      </div>
    </div>
  );
}

/* ============================================================================
   SACOLA — cart drawer
   ============================================================================ */

function CartItemRow({ item, onChangeQty }) {
  return (
    <div className="cart-item">
      <MediaSlot tone={item.tone} src={item.image} alt={item.name} compact className="cart-item__thumb" />
      <div className="cart-item__info">
        <p className="cart-item__name">{item.name}</p>
        <p className="cart-item__price">{formatBRL(item.price)}</p>
      </div>
      <Stepper qty={item.qty} onChange={(n) => onChangeQty(item.id, n)} min={0} size="s" />
    </div>
  );
}

function ReceivingMethodPicker({ method, onChange }) {
  return (
    <div className="receiving">
      <p className="cart__section-label">Como você quer receber?</p>
      <button
        type="button"
        className={`receiving__option ${method === "retirar" ? "receiving__option--active" : ""}`}
        onClick={() => onChange("retirar")}
      >
        <span className="receiving__radio" />
        <span className="receiving__body">
          <span className="receiving__title">Retirar na Lele Pan</span>
          <span className="receiving__sub">Sem taxa de entrega</span>
        </span>
      </button>
      <button
        type="button"
        className={`receiving__option ${method === "entrega" ? "receiving__option--active" : ""}`}
        onClick={() => onChange("entrega")}
      >
        <span className="receiving__radio" />
        <span className="receiving__body">
          <span className="receiving__title">Receber em casa</span>
          <span className="receiving__sub">Taxa de entrega</span>
        </span>
      </button>
    </div>
  );
}

function PickupPicker({ time, onChange }) {
  const slots = useMemo(() => getPickupSlots(), []);
  return (
    <div className="pickup">
      <p className="cart__section-label">Retirada</p>
      <p className="pickup__address">{STORE.address}</p>
      <div className="pickup__slots">
        {slots.map((slot) => (
          <button
            key={slot}
            type="button"
            className={`pickup__slot ${time === slot ? "pickup__slot--active" : ""}`}
            onClick={() => onChange(slot)}
          >
            {slot}
          </button>
        ))}
      </div>
    </div>
  );
}

function DeliveryAddressField({ address, onChange }) {
  const fee = getDeliveryFee();
  return (
    <div className="delivery">
      <p className="cart__section-label">Endereço de entrega</p>
      <textarea
        className="delivery__input"
        placeholder="Rua, número, bairro..."
        value={address}
        onChange={(e) => onChange(e.target.value)}
        rows={2}
      />
      <p className="delivery__fee-note">
        {fee == null ? "Entrega: valor calculado pela Lele Pan" : `Entrega: ${formatBRL(fee)}`}
      </p>
    </div>
  );
}

function CartDrawer({ open, items, total, onChangeQty, onClose, onGoToMenu, profile, onOrderCompleted }) {
  const reduced = usePrefersReducedMotion();
  const [orderNumber, setOrderNumber] = useState(generateOrderNumber);
  const [method, setMethod] = useState("retirar");
  const [pickupTime, setPickupTime] = useState(() => getPickupSlots()[0] || "Agora");
  const [address, setAddress] = useState(() => (profile && profile.endereco) || "");

  // Enrolled Círculo members shouldn't have to retype a saved address.
  useEffect(() => {
    if (profile && profile.endereco) setAddress(profile.endereco);
  }, [profile]);

  useEffect(() => {
    if (!open) return;
    document.body.style.overflow = "hidden";
    const onKey = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [open, onClose]);

  const deliveryFee = getDeliveryFee();
  const deliveryDisplayFee = method === "retirar" ? 0 : deliveryFee;
  const displayTotal = method === "retirar" ? total : total + (deliveryFee || 0);
  const addressMissing = method === "entrega" && !address.trim();

  const message = useMemo(
    () =>
      buildWhatsAppMessage({
        orderNumber,
        items,
        subtotal: total,
        method,
        pickupTime,
        address,
        deliveryFee,
      }),
    [orderNumber, items, total, method, pickupTime, address, deliveryFee]
  );

  // Best available signal for "order completed" without a real backend: the
  // customer actually handing the order off to WhatsApp. Clears the cart and
  // hands a fresh order number to the next one. A production build should
  // instead increment this when the bakery confirms/fulfills the order.
  const handleWhatsAppClick = (e) => {
    if (addressMissing) {
      e.preventDefault();
      return;
    }
    onOrderCompleted();
    setOrderNumber(generateOrderNumber());
  };

  return (
    <div className={`cart-overlay ${open ? "cart-overlay--open" : ""}`} aria-hidden={!open}>
      <div className="cart-overlay__scrim" onClick={onClose} />
      <aside className={`cart ${open ? "cart--open" : ""} ${reduced ? "cart--reduced" : ""}`} role="dialog" aria-modal="true" aria-label="Sua sacola">
        <div className="cart__header">
          <h2 className="cart__title">
            SUA
            <br />
            SACOLA
          </h2>
          <button type="button" className="cart__close" onClick={onClose} aria-label="Fechar sacola">
            <IconClose size={20} strokeWidth={1.6} />
          </button>
        </div>

        {items.length === 0 ? (
          <div className="cart__empty">
            <p>Ainda não tem nada na sua sacola.</p>
            <EditorialLink onClick={onGoToMenu}>VER O QUE SAIU DO FORNO</EditorialLink>
          </div>
        ) : (
          <>
            <div className="cart__scroll">
              <div className="cart__list">
                {items.map((item) => (
                  <CartItemRow key={item.id} item={item} onChangeQty={onChangeQty} />
                ))}
              </div>

              <ReceivingMethodPicker method={method} onChange={setMethod} />

              {method === "retirar" ? (
                <PickupPicker time={pickupTime} onChange={setPickupTime} />
              ) : (
                <DeliveryAddressField address={address} onChange={setAddress} />
              )}
            </div>

            <div className="cart__footer">
              <div className="cart__totals">
                <div className="cart__totals-row">
                  <span>Produtos</span>
                  <span>{formatBRL(total)}</span>
                </div>
                <div className="cart__totals-row">
                  <span>Entrega</span>
                  <span>{deliveryDisplayFee == null ? "A combinar" : formatBRL(deliveryDisplayFee)}</span>
                </div>
                <div className="cart__totals-row cart__totals-row--total">
                  <span>TOTAL</span>
                  <span className="cart__total-value">{formatBRL(displayTotal)}</span>
                </div>
              </div>
              <a
                className={`btn-whatsapp ${addressMissing ? "btn-whatsapp--disabled" : ""}`}
                href={addressMissing ? undefined : whatsappUrl(message)}
                target="_blank"
                rel="noopener noreferrer"
                aria-disabled={addressMissing}
                onClick={handleWhatsAppClick}
              >
                CONTINUAR NO WHATSAPP <IconArrowRight size={16} strokeWidth={1.8} />
              </a>
              {addressMissing && <p className="cart__hint">Adicione seu endereço para continuar.</p>}
            </div>
          </>
        )}
      </aside>
    </div>
  );
}

/* ============================================================================
   DESDE 1988 — heritage
   ============================================================================ */

function Heritage() {
  return (
    <section id="desde-1988" className="heritage">
      <div className="container heritage__grid">
        <div className="heritage__text">
          <h2 className="heritage__year">DESDE 1988</h2>
          <p className="heritage__line">O mesmo forno. O mesmo bairro. Todos os dias.</p>
          <div className="heritage__cta">
            <EditorialLink as="a" href="#/desde-1988">ENTRAR NA DESDE 1988</EditorialLink>
          </div>
        </div>
        <MediaSlot
          tone="heritage"
          src={HERITAGE_MEDIA.src}
          videoSrc={HERITAGE_MEDIA.video}
          label="Foto editorial"
          className="heritage__media"
        />
      </div>
    </section>
  );
}

/* ============================================================================
   MEMÓRIAS
   ============================================================================ */

function Memorias() {
  return (
    <section className="memorias">
      <div className="container">
        <blockquote className="memorias__quote">
          “…tomar um café com seu Carlão do Peruche na Le Pan…”
          <span className="memorias__attr">— Tadeu Kaçula</span>
        </blockquote>
        <p className="memorias__source"><em>Casa Verde: Uma Pequena África Paulistana</em></p>
      </div>
    </section>
  );
}

/* ============================================================================
   CÍRCULO LELE — "para quem sempre volta"
   ============================================================================ */

function FavoriteShowcase({ product, onOpenDetail, onExplore, lead }) {
  const imgRef = useRef(null);

  if (!product) {
    return (
      <div className="circulo__block circulo__favorite circulo__favorite--empty">
        <p className="circulo__eyebrow">Seu favorito</p>
        <h3 className="circulo__empty-title">Ainda estamos te conhecendo.</h3>
        <p className="circulo__empty-line">Encontre um novo favorito.</p>
        <EditorialLink onClick={onExplore}>EXPLORAR CARDÁPIO</EditorialLink>
      </div>
    );
  }

  const handleOpen = () => {
    const rect = imgRef.current ? imgRef.current.getBoundingClientRect() : null;
    onOpenDetail(product, rect);
  };

  return (
    <div className="circulo__block circulo__favorite">
      <p className="circulo__eyebrow">Seu favorito</p>
      {lead && <p className="circulo__lead">{lead}</p>}
      <div className="circulo__favorite-grid">
        <div className="circulo__favorite-media" onClick={handleOpen} role="button" tabIndex={0}
          onKeyDown={(e) => { if (e.key === "Enter") handleOpen(); }}
        >
          <MediaSlot tone={product.tone} src={product.image} videoSrc={product.video} alt={product.name} label="Foto do produto" ref={imgRef} />
        </div>
        <div className="circulo__favorite-info">
          <h3 className="circulo__favorite-name">{product.name}</h3>
          <p className="circulo__favorite-desc">{product.description}</p>
          <span className="circulo__favorite-price">{formatBRL(product.price)}</span>
          <div className="circulo__favorite-cta">
            <PrimaryButton onClick={handleOpen}>
              PEDIR DE NOVO <IconArrowRight size={16} strokeWidth={1.8} />
            </PrimaryButton>
          </div>
        </div>
      </div>
    </div>
  );
}

function RecentOrderRow({ order, onReorder, onGoToCart }) {
  const [state, setState] = useState("idle"); // idle | added
  const resolved = useMemo(() => resolveOrderItems(order), [order]);
  if (!resolved.length) return null;

  const handleReorder = () => {
    onReorder(resolved.map((i) => ({ id: i.id, qty: i.qty })));
    setState("added");
  };

  return (
    <div className="recent-order">
      <div className="recent-order__info">
        <p className="recent-order__date">{order.dateLabel}</p>
        <p className="recent-order__items">{orderLabel(resolved)}</p>
        <p className="recent-order__price">{formatBRL(orderTotal(resolved))}</p>
      </div>
      {state === "idle" ? (
        <EditorialLink onClick={handleReorder} className="recent-order__cta">
          PEDIR DE NOVO
        </EditorialLink>
      ) : (
        <div className="recent-order__confirm">
          <span className="recent-order__confirm-label">
            PEDIDO ADICIONADO <IconCheck size={14} strokeWidth={1.8} />
          </span>
          <EditorialLink onClick={onGoToCart}>IR PARA A SACOLA</EditorialLink>
        </div>
      )}
    </div>
  );
}

function RecentOrders({ orders, onReorder, onGoToCart, onExplore, lead }) {
  if (!orders.length) {
    return (
      <div className="circulo__block">
        <p className="circulo__eyebrow">Pedidos recentes</p>
        <h3 className="circulo__empty-title circulo__empty-title--s">
          Seu primeiro pedido pode começar aqui.
        </h3>
        <EditorialLink onClick={onExplore}>VER O CARDÁPIO</EditorialLink>
      </div>
    );
  }
  return (
    <div className="circulo__block">
      <p className="circulo__eyebrow">Pedidos recentes</p>
      {lead && <p className="circulo__lead">{lead}</p>}
      <div className="recent-orders-list">
        {orders.slice(0, 3).map((order) => (
          <RecentOrderRow key={order.id} order={order} onReorder={onReorder} onGoToCart={onGoToCart} />
        ))}
      </div>
    </div>
  );
}

function MimosRewardRow({ reward, balance, isRedeemed, onRedeem, onUseNow, onSaveForLater }) {
  const locked = balance < reward.cost;
  return (
    <div className="mimos-reward">
      <div className="mimos-reward__info">
        {reward.badge && <span className="mimos-badge">{reward.badge}</span>}
        <p className="mimos-reward__name">{reward.name}</p>
        <p className="mimos-reward__cost">{reward.cost} MIMOS</p>
      </div>
      {isRedeemed ? (
        <div className="mimos-reward__confirm">
          <span className="mimos-reward__confirm-label">
            MIMO RESGATADO <IconCheck size={14} strokeWidth={1.8} />
          </span>
          <div className="mimos-reward__confirm-actions">
            {reward.productId && <EditorialLink onClick={onUseNow}>USAR AGORA</EditorialLink>}
            <EditorialLink onClick={onSaveForLater}>GUARDAR PARA DEPOIS</EditorialLink>
          </div>
        </div>
      ) : locked ? (
        <span className="mimos-reward__locked">Faltam {reward.cost - balance} Mimos</span>
      ) : (
        <EditorialLink onClick={onRedeem}>TROCAR MIMOS</EditorialLink>
      )}
    </div>
  );
}

function MimosRewards({ onReorder, onGoToCart, lead }) {
  const [balance, setBalance] = useState(MIMOS_BALANCE);
  const [redeemedId, setRedeemedId] = useState(null);
  const nextReward = useMemo(() => findNextReward(balance), [balance]);

  const handleRedeem = (reward) => {
    if (balance < reward.cost) return;
    setBalance((b) => b - reward.cost);
    setRedeemedId(reward.id);
  };
  const handleUseNow = (reward) => {
    if (reward.productId) {
      onReorder([{ id: reward.productId, qty: 1 }]);
      onGoToCart();
    }
    setRedeemedId(null);
  };
  const handleSaveForLater = () => setRedeemedId(null);

  return (
    <div className="circulo__block">
      <p className="circulo__eyebrow">Meus Mimos</p>
      {lead && <p className="circulo__lead">{lead}</p>}
      <div className="mimos__balance-row">
        <span className="mimos__balance">{balance}</span>
        <span className="mimos__balance-label">mimos</span>
      </div>
      <p className="mimos__line">
        Você voltou {MIMOS_VISITS_THIS_MONTH} vezes este mês
        {nextReward ? ` — faltam ${nextReward.cost - balance} Mimos para ${nextReward.name}.` : "."}
      </p>
      <div className="mimos-list">
        {MIMOS_REWARDS.map((reward) => (
          <MimosRewardRow
            key={reward.id}
            reward={reward}
            balance={balance}
            isRedeemed={redeemedId === reward.id}
            onRedeem={() => handleRedeem(reward)}
            onUseNow={() => handleUseNow(reward)}
            onSaveForLater={handleSaveForLater}
          />
        ))}
      </div>
    </div>
  );
}

function CirculoSurpresa() {
  const [open, setOpen] = useState(false);
  // Mock rotation: which event shows is deterministic-by-day here, standing
  // in for whatever a real backend would pick for this specific customer.
  const event = useMemo(() => SURPRESA_EVENTS[new Date().getDay() % SURPRESA_EVENTS.length], []);
  return (
    <div className="circulo__block circulo__surprise">
      <p className="circulo__eyebrow">Surpresas</p>
      {!open ? (
        <button type="button" className="surprise-trigger" onClick={() => setOpen(true)}>
          <IconGift size={20} strokeWidth={1.6} />
          <span>Tem uma surpresa para você.</span>
        </button>
      ) : (
        <div className="surprise-content">
          <span className="mimos-badge surprise-badge">{event.badge}</span>
          <p className="surprise-message">{event.message}</p>
          {event.bonus && <p className="surprise-bonus">{event.bonus}</p>}
        </div>
      )}
    </div>
  );
}

const CIRCULO_ORDERS_REQUIRED = 5;

function CirculoTeaser({ completedOrders }) {
  const ref = useRef(null);
  const reduced = usePrefersReducedMotion();
  const revealed = useRevealOnce(ref) || reduced;
  const remaining = Math.max(0, CIRCULO_ORDERS_REQUIRED - completedOrders);

  return (
    <div ref={ref} className={`circulo__intro ${revealed ? "circulo__intro--revealed" : ""}`}>
      <h2 className="circulo__title">CÍRCULO LELE</h2>
      <p className="circulo__tagline">Falta pouco.</p>
      <p className="circulo__gate-progress">
        Faltam {remaining} {remaining === 1 ? "pedido" : "pedidos"} para desbloquear.
      </p>
    </div>
  );
}

// Shared profile form: first-time onboarding AND "Minhas informações" editing.
function CirculoOnboardingSimple({ initial, submitLabel = "ENTRAR NO CÍRCULO", lead, onSubmit, onCancel }) {
  const [nome, setNome] = useState((initial && initial.nome) || "");
  const [nascimento, setNascimento] = useState((initial && initial.nascimento) || "");
  const [telefone, setTelefone] = useState((initial && initial.telefone) || "");
  const [endereco, setEndereco] = useState((initial && initial.endereco) || "");
  const [error, setError] = useState("");

  const dobParsed = parseDateBR(nascimento);
  const dobError = nascimento !== "" && nascimento.length === 10 && !dobParsed;

  const handleClick = () => {
    if (!nome.trim()) return setError("Como podemos te chamar?");
    if (nascimento !== "" && !dobParsed) return setError("Confira a data de nascimento (DD/MM/AAAA).");
    setError("");
    onSubmit({
      nome: formatName(nome),
      nascimento, // DD/MM/AAAA, exactly as shown to the customer
      nascimentoISO: dobParsed ? dobParsed.iso : null, // backend-safe form
      telefone: telefone.trim(),
      endereco: endereco.trim(),
    });
  };

  return (
    <div className="circulo__intro circulo__intro--revealed circulo__enroll-inline">
      {lead && <p className="circulo__enroll-lead">{lead}</p>}
      <div className="enroll__form">
        <label className="enroll__field">
          <span>Nome</span>
          <input type="text" value={nome} onChange={(e) => setNome(e.target.value)} placeholder="Seu nome" autoComplete="given-name" />
        </label>
        <label className="enroll__field">
          <span>Data de nascimento</span>
          <input
            type="text"
            inputMode="numeric"
            value={nascimento}
            onChange={(e) => setNascimento(maskDateBR(e.target.value))}
            placeholder="DD/MM/AAAA"
            maxLength={10}
            aria-invalid={dobError}
          />
          {dobError && <span className="enroll__field-error">Data inválida. Use DD/MM/AAAA.</span>}
        </label>
        <label className="enroll__field">
          <span>Telefone</span>
          <input type="tel" value={telefone} onChange={(e) => setTelefone(e.target.value)} placeholder="(11) 90000-0000" autoComplete="tel" />
        </label>
        <label className="enroll__field">
          <span>Endereço</span>
          <textarea rows={2} value={endereco} onChange={(e) => setEndereco(e.target.value)} placeholder="Rua, número, bairro..." />
        </label>
        {error && <p className="enroll__field-error" role="alert">{error}</p>}
        <PrimaryButton type="button" onClick={handleClick} className="enroll__submit">
          {submitLabel} <IconArrowRight size={16} strokeWidth={1.8} />
        </PrimaryButton>
        {onCancel && (
          <button type="button" className="editorial-link" style={{ color: "var(--white)", alignSelf: "center" }} onClick={onCancel}>
            CANCELAR
          </button>
        )}
      </div>
    </div>
  );
}

function OQueFica() {
  return (
    <div className="circulo__block circulo__memory">
      <p className="circulo__eyebrow">O que fica</p>
      <p className="circulo__memory-line">
        Tudo muda com o tempo. Mas o cheiro de pão quentinho de manhã cedo é sempre o mesmo.
      </p>
      <p className="circulo__memory-anchor">Desde 1988.</p>
    </div>
  );
}

function CirculoHome({ profile, products, favorites, onOpenDetail, onReorder, onGoToCart, onExplore, onVoltar, onShare, onEditProfile }) {
  const favoriteProduct = useMemo(
    () => products.find((p) => favorites[p.id]) || null,
    [products, favorites]
  );
  const firstName = profile && profile.nome ? profile.nome.trim().split(" ")[0] : "";

  return (
    <>
      <div className="circulo__intro circulo__intro--revealed">
        <h2 className="circulo__title">
          {firstName ? `Que bom ter você de volta, ${firstName}.` : "Que bom ter você de volta."}
        </h2>
        <p className="circulo__tagline">Seu cantinho continua aqui.</p>
      </div>
      <div className="circulo__layout">
        <FavoriteShowcase
          product={favoriteProduct}
          onOpenDetail={onOpenDetail}
          onExplore={onExplore}
          lead={favoriteProduct ? "Hoje é dia de repetir?" : null}
        />
        <div className="circulo__duo">
          <RecentOrders
            orders={RECENT_ORDERS}
            onReorder={onReorder}
            onGoToCart={onGoToCart}
            onExplore={onExplore}
            lead="Alguma coisa te trouxe de volta?"
          />
          <MimosRewards onReorder={onReorder} onGoToCart={onGoToCart} lead="Tem uma coisinha guardada para você." />
        </div>
        <CirculoSurpresa />
        <div className="circulo__actions">
          <p className="circulo__share-line">Você também faz parte da história.</p>
          <div className="circulo__share-row">
            <PrimaryButton type="button" onClick={onShare}>
              COMPARTILHAR UMA MEMÓRIA <IconArrowRight size={16} strokeWidth={1.8} />
            </PrimaryButton>
            <EditorialLink onClick={onEditProfile}>MINHAS INFORMAÇÕES</EditorialLink>
          </div>
        </div>
        <OQueFica />
        <div className="circulo__voltar">
          <EditorialLink direction="left" onClick={onVoltar}>VOLTAR PARA A CASA</EditorialLink>
        </div>
      </div>
    </>
  );
}

function CirculoLele({ sectionRef, products, favorites, onOpenDetail, onReorder, onGoToCart, onExplore, onGoHome, completedOrders, profile, onSaveProfile, openRequest }) {
  // The overlay is just "open or closed". WHETHER onboarding is needed comes
  // from the saved profile, so it happens exactly once.
  const [showCirculo, setShowCirculo] = useState(false);
  const [panel, setPanel] = useState("home"); // home | profile | composer
  const eligible = completedOrders >= CIRCULO_ORDERS_REQUIRED;
  const onboarded = !!(profile && profile.onboardingCompleted);
  const isMember = eligible && onboarded;
  const author = { id: getVisitorId(), name: (profile && profile.nome) || "Membro do Círculo", isMember };

  const enter = (p = "home") => {
    setPanel(p);
    setShowCirculo(true);
  };

  // Lets other views (Desde 1988) send a member straight in.
  useEffect(() => {
    if (openRequest && openRequest.n > 0 && isMember) enter(openRequest.panel || "home");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [openRequest && openRequest.n]);

  // Lock page scroll behind the overlay.
  useEffect(() => {
    if (!showCirculo) return undefined;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [showCirculo]);

  const handleVoltar = () => {
    setShowCirculo(false);
    onGoHome();
  };

  const [saved, setSaved] = useState(false);
  const firstName = profile && profile.nome ? profile.nome.trim().split(" ")[0] : "";

  return (
    <section id="circulo" ref={sectionRef} className="circulo">
      <div className="container">
        {!eligible ? (
          <CirculoTeaser completedOrders={completedOrders} />
        ) : !onboarded ? (
          <div>
            <div className="circulo__intro circulo__intro--revealed" style={{ marginBottom: 32 }}>
              <h2 className="circulo__title">CÍRCULO LELE</h2>
            </div>
            <CirculoOnboardingSimple
              lead="Antes de entrar, queremos guardar algumas coisas sobre você."
              onSubmit={(data) => {
                onSaveProfile(data);
                enter("home");
              }}
            />
          </div>
        ) : (
          <div className="circulo__intro circulo__intro--revealed circulo__welcome">
            <h2 className="circulo__title">CÍRCULO LELE</h2>
            <p className="circulo__tagline">{firstName ? `Bem-vindo de volta, ${firstName}.` : "Bem-vindo de volta."}</p>
            <PrimaryButton type="button" onClick={() => enter("home")}>
              ENTRAR <IconArrowRight size={16} strokeWidth={1.8} />
            </PrimaryButton>
          </div>
        )}
      </div>
      {showCirculo && isMember && (
        <div className="circulo-home-overlay" role="dialog" aria-modal="true" aria-label="Círculo Lele">
          <div className="circulo-home-overlay__scrim" />
          <div className="circulo-home-overlay__panel">
            <div className="container">
              {panel === "home" && (
                <CirculoHome
                  profile={profile}
                  products={products}
                  favorites={favorites}
                  onOpenDetail={onOpenDetail}
                  onReorder={onReorder}
                  onGoToCart={onGoToCart}
                  onExplore={onExplore}
                  onVoltar={handleVoltar}
                  onShare={() => setPanel("composer")}
                  onEditProfile={() => { setSaved(false); setPanel("profile"); }}
                />
              )}
              {panel === "profile" && (
                <div>
                  <EditorialLink direction="left" onClick={() => setPanel("home")} style={{ color: "var(--white)", marginBottom: 32 }}>
                    VOLTAR AO CÍRCULO
                  </EditorialLink>
                  <div className="circulo__intro circulo__intro--revealed" style={{ marginBottom: 32 }}>
                    <h2 className="circulo__title">Minhas informações</h2>
                    <p className="circulo__tagline">Você continua no Círculo. É só atualizar o que mudou.</p>
                  </div>
                  <CirculoOnboardingSimple
                    initial={profile}
                    submitLabel="SALVAR"
                    onSubmit={(data) => {
                      onSaveProfile(data);
                      setSaved(true);
                      setPanel("home");
                    }}
                    onCancel={() => setPanel("home")}
                  />
                </div>
              )}
              {panel === "composer" && (
                <MemoryComposer
                  author={author}
                  onBack={() => setPanel("home")}
                  onViewDesde={() => {
                    setShowCirculo(false);
                    window.location.hash = "/desde-1988";
                  }}
                />
              )}
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

/* ============================================================================
   LOCALIZAÇÃO
   ============================================================================ */

function Localizacao() {
  const [open, setOpen] = useState(() => isOpenNow());

  useEffect(() => {
    const id = window.setInterval(() => setOpen(isOpenNow()), 60000);
    return () => window.clearInterval(id);
  }, []);

  const mapQuery = encodeURIComponent(STORE.address);
  const directionsUrl = `https://www.google.com/maps/dir/?api=1&destination=${mapQuery}`;
  const embedUrl = `https://www.google.com/maps?q=${mapQuery}&output=embed`;

  return (
    <section id="localizacao" className="location">
      <div className="container location__grid">
        <div className="location__info">
          <p className="circulo__eyebrow location__eyebrow">Visite a loja</p>
          <h2 className="location__name">{STORE.name}</h2>
          <address className="location__address">
            {STORE.addressLines.map((l) => (
              <span key={l} style={{ display: "block" }}>{l}</span>
            ))}
          </address>
          <span className={`location__status ${open ? "location__status--open" : "location__status--closed"}`}>
            {open ? "ABERTO AGORA" : "FECHADO AGORA"}
          </span>

          <div className="location__hours">
            {WEEK_HOURS.map((row) => (
              <div key={row.day} className="location__hours-row">
                <span>{row.day}</span>
                <span>{row.hours}</span>
              </div>
            ))}
          </div>

          <a className="location__phone" href={`tel:+${STORE.phoneDigits}`}>
            {STORE.phoneDisplay}
          </a>

          <div className="location__cta">
            <a className="btn-primary" href={STORE.mapsUrl} target="_blank" rel="noopener noreferrer">
              ABRIR NO MAPA <IconArrowRight size={16} strokeWidth={1.8} />
            </a>
            <EditorialLink as="a" href={directionsUrl} target="_blank" rel="noopener noreferrer">
              COMO CHEGAR
            </EditorialLink>
          </div>
        </div>
        <div className="location__map">
          <iframe
            title="Localização da Lele Pan no mapa"
            src={embedUrl}
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
      </div>
    </section>
  );
}

/* ============================================================================
   FOOTER
   ============================================================================ */

function Footer() {
  return (
    <footer className="footer">
      <div className="container footer__inner">
        <span className="footer__logo">Lele Pan</span>
        <span className="footer__meta">Padaria de bairro, desde 1988.</span>
        <nav className="footer__links" aria-label="Informações legais">
          <a className="footer__link" href="#/privacidade">Política de Privacidade</a>
          <a className="footer__link" href="#/termos">Termos de Uso</a>
        </nav>
      </div>
    </footer>
  );
}

/* ============================================================================
   APP
   ============================================================================ */

function parseHash() {
  const h = typeof window !== "undefined" ? window.location.hash : "";
  if (h.startsWith("#/desde-1988")) return "desde";
  if (h === "#/privacidade") return "privacidade";
  if (h === "#/termos") return "termos";
  return "home";
}

export default function CasaLelePan() {
  const [cart, setCart] = useState({});
  const [favorites, setFavorites] = useState(readFavoritesSync);
  const [detail, setDetail] = useState(null); // { product, sourceRect }
  const [cartOpen, setCartOpen] = useState(false);
  const [active, setActive] = useState("casa");
  const [view, setView] = useState(parseHash); // home | desde | privacidade | termos
  const [circuloOpen, setCirculoOpen] = useState({ n: 0, panel: "home" });
  const pendingScroll = useRef(null);

  // Círculo eligibility + profile persist in localStorage (prototype-grade,
  // per browser). A real build replaces this with an authenticated backend.
  const [completedOrders, setCompletedOrders] = useState(() => readNumberSync("circulo:completedOrders"));
  const [circuloProfile, setCirculoProfile] = useState(readProfileSync);

  useEffect(() => {
    // Fallback for environments that only have window.storage.
    let cancelled = false;
    (async () => {
      if (safeStorageGetSync("circulo:profile") != null) return;
      const profileRes = await safeStorageGet("circulo:profile");
      if (!cancelled && profileRes && profileRes.value) {
        try {
          setCirculoProfile({ ...JSON.parse(profileRes.value), onboardingCompleted: true });
        } catch (e) {
          // ignore corrupted value
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  // Console-only test hooks — Círculo can be tested without 5 real checkouts.
  useEffect(() => {
    window.__lelePanDev = {
      setOrders(n) {
        const value = Math.max(0, Number(n) || 0);
        setCompletedOrders(value);
        safeStorageSet("circulo:completedOrders", String(value));
        return value;
      },
      resetCirculo() {
        setCompletedOrders(0);
        setCirculoProfile(null);
        safeStorageDelete("circulo:completedOrders");
        safeStorageDelete("circulo:profile");
      },
      seedMemories: seedDemoMemories,
      clearMemories: clearAllMemories,
    };
    return () => {
      delete window.__lelePanDev;
    };
  }, []);

  const heroRef = useRef(null);
  const freshRef = useRef(null);
  const circuloRef = useRef(null);
  const reduced = usePrefersReducedMotion();

  const refsByKey = useMemo(
    () => ({ casa: heroRef, cardapio: freshRef, circulo: circuloRef }),
    []
  );

  const goHome = useCallback(() => {
    if (window.location.hash) {
      window.history.pushState(null, "", window.location.pathname + window.location.search);
    }
    setView("home");
  }, []);

  // Hash routing: #/desde-1988, #/privacidade, #/termos (back button works).
  useEffect(() => {
    const onHash = () => {
      setView(parseHash());
      if (parseHash() !== "home") window.scrollTo(0, 0);
    };
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  const doScroll = useCallback(
    (key) => {
      const ref = refsByKey[key];
      if (ref && ref.current) {
        ref.current.scrollIntoView({ behavior: reduced ? "auto" : "smooth", block: "start" });
        setActive(key);
      }
    },
    [refsByKey, reduced]
  );

  const scrollTo = useCallback(
    (key) => {
      if (key === "desde") {
        window.location.hash = "/desde-1988";
        return;
      }
      if (view !== "home") {
        pendingScroll.current = key;
        goHome();
        return;
      }
      doScroll(key);
    },
    [view, goHome, doScroll]
  );

  // After returning home from another view, perform the requested scroll.
  useEffect(() => {
    if (view === "home") {
      const key = pendingScroll.current;
      pendingScroll.current = null;
      if (key) window.setTimeout(() => doScroll(key), 50);
      else window.scrollTo(0, 0);
    }
  }, [view, doScroll]);

  const handleQuickAdd = useCallback((product, delta) => {
    setCart((prev) => {
      const nextQty = Math.max(0, (prev[product.id] || 0) + delta);
      const next = { ...prev };
      if (nextQty === 0) delete next[product.id];
      else next[product.id] = nextQty;
      return next;
    });
  }, []);

  const handleSetQty = useCallback((productId, qty) => {
    setCart((prev) => {
      const next = { ...prev };
      if (qty <= 0) delete next[productId];
      else next[productId] = qty;
      return next;
    });
  }, []);

  const handleAddFromDetail = useCallback((product, qty) => {
    setCart((prev) => ({ ...prev, [product.id]: (prev[product.id] || 0) + qty }));
  }, []);

  const handleToggleFav = useCallback((productId) => {
    setFavorites((prev) => {
      const next = { ...prev, [productId]: !prev[productId] };
      safeStorageSet("lelepan:favorites", JSON.stringify(next));
      return next;
    });
  }, []);

  const handleReorder = useCallback((items) => {
    setCart((prev) => {
      const next = { ...prev };
      items.forEach(({ id, qty }) => {
        next[id] = (next[id] || 0) + qty;
      });
      return next;
    });
  }, []);

  // Called when a checkout is actually handed off to WhatsApp — the closest
  // available signal to "order completed" without a real backend.
  const handleOrderCompleted = useCallback(() => {
    setCompletedOrders((n) => {
      const next = n + 1;
      safeStorageSet("circulo:completedOrders", String(next));
      return next;
    });
    setCart({});
  }, []);

  // Used for first onboarding AND for editing. Editing never resets
  // onboarding: onboardingCompleted is always true once saved.
  const handleSaveProfile = useCallback((data) => {
    setCirculoProfile((prev) => {
      const next = { ...(prev || {}), ...data, onboardingCompleted: true };
      safeStorageSet("circulo:profile", JSON.stringify(next));
      return next;
    });
  }, []);

  const handleOpenDetail = useCallback((product, rect) => {
    setDetail({ product, sourceRect: rect });
  }, []);

  const handleCloseDetail = useCallback(() => setDetail(null), []);

  const isMember = completedOrders >= CIRCULO_ORDERS_REQUIRED && !!(circuloProfile && circuloProfile.onboardingCompleted);

  const goToCirculo = useCallback(
    (panel) => {
      pendingScroll.current = "circulo";
      if (view === "home") {
        doScroll("circulo");
        pendingScroll.current = null;
      } else {
        goHome();
      }
      if (isMember) setCirculoOpen((o) => ({ n: o.n + 1, panel: panel || "home" }));
    },
    [view, goHome, doScroll, isMember]
  );

  // Scroll-spy (only while the home view is mounted).
  useEffect(() => {
    if (view !== "home") return undefined;
    const sections = [
      { key: "casa", el: heroRef.current },
      { key: "cardapio", el: freshRef.current },
      { key: "circulo", el: circuloRef.current },
    ].filter((s) => s.el);
    if (!sections.length) return undefined;
    const observer = new IntersectionObserver(
      (entries) => {
        let best = null;
        entries.forEach((entry) => {
          if (entry.isIntersecting && (!best || entry.intersectionRatio > best.intersectionRatio)) {
            best = entry;
          }
        });
        if (best) {
          const match = sections.find((s) => s.el === best.target);
          if (match) setActive(match.key);
        }
      },
      { threshold: [0.2, 0.4, 0.6], rootMargin: "-80px 0px -40% 0px" }
    );
    sections.forEach((s) => observer.observe(s.el));
    return () => observer.disconnect();
  }, [view]);

  const cartItems = useMemo(
    () =>
      Object.entries(cart)
        .filter(([, qty]) => qty > 0)
        .map(([id, qty]) => ({ ...PRODUCTS.find((p) => p.id === id), qty })),
    [cart]
  );
  const cartCount = useMemo(() => cartItems.reduce((s, i) => s + i.qty, 0), [cartItems]);
  const cartTotal = useMemo(() => cartItems.reduce((s, i) => s + i.qty * i.price, 0), [cartItems]);

  const navActive = view === "desde" ? "desde" : view === "home" ? active : "";

  return (
    <div className="lele-root">
      <style>{STYLES}</style>
      <style>{DESDE_STYLES}</style>

      <Nav cartCount={cartCount} onOpenCart={() => setCartOpen(true)} onNavigate={scrollTo} active={navActive} />

      <main>
        {view === "home" && (
          <>
            <Hero sectionRef={heroRef} onCTA={() => scrollTo("cardapio")} />
            <FreshSection
              sectionRef={freshRef}
              products={PRODUCTS}
              cart={cart}
              favorites={favorites}
              onToggleFav={handleToggleFav}
              onQuickAdd={handleQuickAdd}
              onOpenDetail={handleOpenDetail}
            />
            <Heritage />
            <Memorias />
            <CirculoLele
              sectionRef={circuloRef}
              products={PRODUCTS}
              favorites={favorites}
              onOpenDetail={handleOpenDetail}
              onReorder={handleReorder}
              onGoToCart={() => setCartOpen(true)}
              onExplore={() => scrollTo("cardapio")}
              onGoHome={() => scrollTo("casa")}
              completedOrders={completedOrders}
              profile={circuloProfile}
              onSaveProfile={handleSaveProfile}
              openRequest={circuloOpen}
            />
            <Localizacao />
          </>
        )}
        {view === "desde" && (
          <Desde1988Page
            isMember={isMember}
            memberName={isMember ? circuloProfile.nome : ""}
            onBack={() => scrollTo("casa")}
            onGoCirculo={() => goToCirculo(isMember ? "composer" : "home")}
          />
        )}
        {(view === "privacidade" || view === "termos") && (
          <LegalPage kind={view} contact={STORE} onBack={() => scrollTo("casa")} />
        )}
      </main>

      <Footer />

      <MobileNav cartCount={cartCount} onOpenCart={() => setCartOpen(true)} onNavigate={scrollTo} active={navActive} />

      {detail && (
        <ProductDetail
          product={detail.product}
          sourceRect={detail.sourceRect}
          qty={cart[detail.product.id] || 0}
          isFav={!!favorites[detail.product.id]}
          onToggleFav={handleToggleFav}
          onAdd={handleAddFromDetail}
          onClose={handleCloseDetail}
        />
      )}

      <CartDrawer
        open={cartOpen}
        items={cartItems}
        total={cartTotal}
        onChangeQty={handleSetQty}
        onClose={() => setCartOpen(false)}
        onGoToMenu={() => {
          setCartOpen(false);
          scrollTo("cardapio");
        }}
        profile={circuloProfile}
        onOrderCompleted={handleOrderCompleted}
      />
    </div>
  );
}

/* ============================================================================
   STYLES — design tokens + component styles
   ============================================================================ */

const STYLES = `
@import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;1,400&family=Inter:wght@400;500;600&display=swap');

.lele-root {
  --black: #171717;
  --gold: #F2C500;
  --gold-deep: #D9AE00;
  --gold-press: #C29B00;
  --white: #F8F8F6;
  --brick: #BE3527;
  --olive: #46552F;
  --olive-deep: #384323;
  --cream: #F3EBDD;

  --font-display: 'Cormorant Garamond', Georgia, serif;
  --font-ui: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;

  --fs-display-xl: clamp(44px, 8.4vw, 96px);
  --fs-display-l: clamp(34px, 5.6vw, 64px);
  --fs-display-m: clamp(28px, 4vw, 48px);
  --fs-h-l: clamp(26px, 3.4vw, 40px);
  --fs-h-m: clamp(22px, 2.6vw, 32px);
  --fs-h-s: 24px;
  --fs-body-l: 18px;
  --fs-body-m: 16px;
  --fs-body-s: 14px;
  --fs-label-l: 13px;
  --fs-label-s: 11px;

  --ease-out: cubic-bezier(0.22, 1, 0.36, 1);
  --ease-in-out: cubic-bezier(0.65, 0, 0.35, 1);
  --t-micro: 180ms;
  --t-standard: 420ms;
  --t-cinematic: 900ms;

  --container-pad: 80px;
  --radius-s: 6px;
  --radius-m: 8px;
  --radius-l: 12px;

  background: var(--white);
  color: var(--black);
  font-family: var(--font-ui);
  font-size: var(--fs-body-m);
  line-height: 1.5;
  -webkit-font-smoothing: antialiased;
}

.lele-root, .lele-root * , .lele-root *::before, .lele-root *::after { box-sizing: border-box; }

:where(.lele-root) h1, :where(.lele-root) h2, :where(.lele-root) h3, :where(.lele-root) p, :where(.lele-root) blockquote { margin: 0; }
:where(.lele-root) button { font-family: inherit; background: none; border: none; padding: 0; color: inherit; }
:where(.lele-root) a { color: inherit; text-decoration: none; }
:where(.lele-root) ul { list-style: none; margin: 0; padding: 0; }

.lele-root *:focus-visible {
  outline: 2px solid var(--gold-deep);
  outline-offset: 3px;
  border-radius: 2px;
}

.container {
  max-width: 1440px;
  margin: 0 auto;
  padding-left: var(--container-pad);
  padding-right: var(--container-pad);
}

@media (max-width: 1199px) {
  .container { --container-pad: 48px; }
}
@media (max-width: 767px) {
  .container { --container-pad: 24px; }
}
@media (max-width: 479px) {
  .container { --container-pad: 20px; }
}

/* -------------------------------------------------------------- media slot */

.media-slot {
  position: relative;
  overflow: hidden;
  width: 100%;
  height: 100%;
  background-size: cover;
}
.media-slot::after {
  content: "";
  position: absolute;
  inset: 0;
  opacity: 0.05;
  mix-blend-mode: overlay;
  pointer-events: none;
  background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='2' stitchTiles='stitch'/></filter><rect width='100%25' height='100%25' filter='url(%23n)'/></svg>");
}
.media-slot--fried { background: radial-gradient(130% 130% at 25% 15%, #EAC077 0%, #C9812F 45%, #7A4419 100%); }
.media-slot--coffee { background: radial-gradient(130% 130% at 25% 15%, #7A5A42 0%, #45301F 55%, #1E140D 100%); }
.media-slot--tomato { background: radial-gradient(130% 130% at 25% 15%, #E7B24A 0%, #C1502B 48%, #7A2418 100%); }
.media-slot--caramel { background: radial-gradient(130% 130% at 25% 15%, #F3E1B8 0%, #D9A45C 50%, #93602A 100%); }
.media-slot--mixed { background: radial-gradient(130% 130% at 25% 15%, #E9C98A 0%, #C77B3A 45%, #6E3A1B 100%); }
.media-slot--combo { background: radial-gradient(130% 130% at 25% 15%, #D98B3E 0%, #A8481F 48%, #5E2313 100%); }
.media-slot--hero { background: radial-gradient(140% 140% at 30% 10%, #C99457 0%, #8A5324 45%, #402512 100%); }
.media-slot--heritage { background: radial-gradient(140% 140% at 70% 20%, #8A6A48 0%, #4A3521 55%, #221509 100%); }

.media-slot__media {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.media-slot__label {
  position: absolute;
  left: 12px;
  bottom: 12px;
  z-index: 1;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 6px 10px;
  border-radius: var(--radius-s);
  background: rgba(23, 23, 23, 0.4);
  color: var(--white);
  font-size: 11px;
  font-weight: 500;
  letter-spacing: 0.02em;
  backdrop-filter: blur(3px);
}
.media-slot__mark {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  color: rgba(248, 248, 246, 0.6);
}

/* ---------------------------------------------------------------- buttons */

.btn-primary {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  height: 48px;
  padding: 0 24px;
  border-radius: var(--radius-m);
  background: var(--gold);
  color: var(--black);
  font-family: var(--font-ui);
  font-weight: 600;
  font-size: var(--fs-label-l);
  letter-spacing: 0.04em;
  cursor: pointer;
  transition: background var(--t-micro) var(--ease-out), transform var(--t-micro) var(--ease-out);
}
.btn-primary:hover { background: var(--gold-deep); }
.btn-primary:active { background: var(--gold-press); transform: scale(0.97); }
.btn-primary--disabled { opacity: 0.4; cursor: not-allowed; }
.btn-primary--added { background: var(--black); color: var(--white); }

.btn-whatsapp {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  height: 52px;
  border-radius: var(--radius-m);
  background: var(--olive);
  color: var(--white);
  font-weight: 600;
  font-size: var(--fs-label-l);
  letter-spacing: 0.04em;
  transition: background var(--t-micro) var(--ease-out), transform var(--t-micro) var(--ease-out);
}
.btn-whatsapp:hover { background: var(--olive-deep); }
.btn-whatsapp:active { transform: scale(0.98); }

.editorial-link {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: var(--fs-label-l);
  font-weight: 500;
  letter-spacing: 0.03em;
  color: var(--black);
  cursor: pointer;
  opacity: 0.85;
  transition: opacity var(--t-micro) var(--ease-out), transform var(--t-micro) var(--ease-out);
}
.editorial-link:hover { opacity: 1; }
.editorial-link:active { transform: translateX(-1px); opacity: 0.7; }

/* ------------------------------------------------------------- fav / add */

.fav-btn {
  position: absolute;
  top: 12px;
  right: 12px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 34px;
  height: 34px;
  border-radius: 50%;
  color: var(--black);
  background: rgba(248, 248, 246, 0.85);
  transition: color var(--t-micro) var(--ease-out), transform var(--t-micro) var(--ease-out);
}
.fav-btn:hover { transform: scale(1.06); }
.fav-btn--active { color: var(--brick); }
.fav-btn--inline { position: static; background: none; width: auto; height: auto; }

.add-control {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 34px;
  padding: 0 12px;
  border-radius: var(--radius-m);
  border: 1px solid var(--black);
  font-size: var(--fs-label-s);
  font-weight: 600;
  letter-spacing: 0.05em;
  transition: background var(--t-micro) var(--ease-out), color var(--t-micro) var(--ease-out), border-color var(--t-micro) var(--ease-out);
}
.add-control:hover { background: var(--black); color: var(--white); }
.add-control--added {
  background: var(--olive);
  border-color: var(--olive);
  color: var(--white);
}

.stepper {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  height: 34px;
  padding: 0 4px;
}
.stepper--m { height: 44px; gap: 16px; }
.stepper__btn {
  width: 26px;
  height: 26px;
  border-radius: 50%;
  border: 1px solid var(--black);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  transition: background var(--t-micro) var(--ease-out), color var(--t-micro) var(--ease-out);
}
.stepper--m .stepper__btn { width: 34px; height: 34px; }
.stepper__btn:hover { background: var(--black); color: var(--white); }
.stepper__value {
  min-width: 16px;
  text-align: center;
  font-weight: 600;
  font-size: var(--fs-body-s);
}
.stepper--m .stepper__value { font-size: var(--fs-body-m); min-width: 20px; }

.tag {
  position: absolute;
  top: 12px;
  left: 12px;
  background: var(--cream);
  color: var(--black);
  font-size: var(--fs-label-s);
  font-weight: 600;
  letter-spacing: 0.06em;
  padding: 5px 10px;
  border-radius: var(--radius-s);
}

/* -------------------------------------------------------------------- nav */

.nav {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 40;
  height: 80px;
  transition: height var(--t-standard) var(--ease-out), background var(--t-standard) var(--ease-out), backdrop-filter var(--t-standard) var(--ease-out);
}
.nav--condensed {
  height: 60px;
  background: rgba(243, 235, 221, 0.82);
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
}
.nav__inner {
  max-width: 1440px;
  margin: 0 auto;
  height: 100%;
  padding: 0 80px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
@media (max-width: 1199px) { .nav__inner { padding: 0 48px; } }
@media (max-width: 767px) { .nav__inner { padding: 0 24px; } }

.nav__logo {
  font-family: var(--font-display);
  font-size: 24px;
  letter-spacing: 0.01em;
  cursor: pointer;
}

.nav__links {
  display: flex;
  align-items: center;
  gap: 40px;
}
@media (max-width: 767px) { .nav__links { display: none; } }

.nav-link {
  position: relative;
  font-size: var(--fs-label-l);
  font-weight: 500;
  letter-spacing: 0.03em;
  padding: 8px 2px;
  cursor: pointer;
  transition: font-weight var(--t-micro) var(--ease-out), opacity var(--t-micro) var(--ease-out);
  opacity: 0.75;
}
.nav-link:hover { opacity: 1; }
.nav-link--active { font-weight: 600; opacity: 1; }
.nav-link--active::after {
  content: "";
  position: absolute;
  left: 2px;
  bottom: 2px;
  width: 4px;
  height: 4px;
  border-radius: 50%;
  background: var(--gold-deep);
}

.nav__bag {
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
}
.nav__bag-badge {
  position: absolute;
  top: -6px;
  right: -8px;
  min-width: 16px;
  height: 16px;
  padding: 0 4px;
  border-radius: 50%;
  background: var(--brick);
  color: var(--white);
  font-size: 10px;
  font-weight: 600;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* ------------------------------------------------------------ mobile nav */

.mobile-nav {
  position: fixed;
  left: 16px;
  right: 16px;
  bottom: 14px;
  z-index: 40;
  height: 68px;
  display: none;
  align-items: center;
  justify-content: space-around;
  background: rgba(243, 235, 221, 0.92);
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  border-radius: var(--radius-l);
  border: 1px solid rgba(23, 23, 23, 0.06);
}
@media (max-width: 767px) { .mobile-nav { display: flex; } }

.mobile-nav__item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
  font-size: 10px;
  font-weight: 500;
  letter-spacing: 0.02em;
  color: var(--black);
  opacity: 0.6;
  cursor: pointer;
}
.mobile-nav__item--active { opacity: 1; }
.mobile-nav__bag-wrap { position: relative; display: inline-flex; }
.mobile-nav__badge {
  position: absolute;
  top: -5px;
  right: -8px;
  min-width: 14px;
  height: 14px;
  padding: 0 3px;
  border-radius: 50%;
  background: var(--brick);
  color: var(--white);
  font-size: 9px;
  font-weight: 600;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* ------------------------------------------------------------------- hero */

.hero {
  position: relative;
  min-height: 100vh;
  display: flex;
  align-items: flex-end;
  overflow: hidden;
}
.hero__media {
  position: absolute;
  inset: 0;
  transform: scale(1.06);
  transition: transform 1400ms var(--ease-out);
}
.hero--ready .hero__media { transform: scale(1); }
.hero__scrim {
  position: absolute;
  inset: 0;
  background: linear-gradient(180deg, rgba(23,23,23,0.05) 0%, rgba(23,23,23,0.55) 100%);
}
.hero__content {
  position: relative;
  z-index: 1;
  padding: 0 80px 96px;
  max-width: 900px;
}
@media (max-width: 1199px) { .hero__content { padding: 0 48px 72px; } }
@media (max-width: 767px) { .hero__content { padding: 0 24px 140px; } }

.hero__headline {
  font-family: var(--font-display);
  font-weight: 500;
  font-size: var(--fs-display-xl);
  line-height: 0.98;
  color: var(--white);
  margin-bottom: 24px;
}
.hero__line {
  display: block;
  opacity: 0;
  transform: translateY(28px);
  transition: opacity var(--t-cinematic) var(--ease-out), transform var(--t-cinematic) var(--ease-out);
}
.hero--ready .hero__line:nth-child(1) { opacity: 1; transform: translateY(0); transition-delay: 200ms; }
.hero--ready .hero__line:nth-child(2) { opacity: 1; transform: translateY(0); transition-delay: 320ms; }
.hero--ready .hero__line:nth-child(3) { opacity: 1; transform: translateY(0); transition-delay: 440ms; }

.hero__sub {
  font-size: var(--fs-body-l);
  color: var(--white);
  max-width: 40ch;
  margin-bottom: 32px;
  opacity: 0;
  transform: translateY(16px);
  transition: opacity var(--t-standard) var(--ease-out) 720ms, transform var(--t-standard) var(--ease-out) 720ms;
}
.hero--ready .hero__sub { opacity: 0.92; transform: translateY(0); }

.hero__cta {
  opacity: 0;
  transform: translateY(12px);
  transition: opacity var(--t-standard) var(--ease-out) 880ms, transform var(--t-standard) var(--ease-out) 880ms;
}
.hero--ready .hero__cta { opacity: 1; transform: translateY(0); }

/* -------------------------------------------------------------- sections */

.section-head { margin-bottom: 48px; }
.section-head__title {
  font-family: var(--font-display);
  font-weight: 500;
  font-size: var(--fs-display-m);
  display: flex;
  align-items: baseline;
  gap: 16px;
  flex-wrap: wrap;
}
.section-head__accent {
  font-style: italic;
  color: var(--brick);
  font-size: 0.55em;
}

.fresh { padding: 120px 0; }
@media (max-width: 767px) { .fresh { padding: 72px 0; } }

/* --------------------------------------------------------- product grid */

.product-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 48px 24px;
}
@media (max-width: 1023px) {
  .product-grid { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 599px) {
  .product-grid { grid-template-columns: 1fr; gap: 40px; }
}

.product-card { display: flex; flex-direction: column; }
.product-card__media {
  position: relative;
  aspect-ratio: 4 / 5;
  border-radius: var(--radius-l);
  overflow: hidden;
  cursor: pointer;
}
.product-card__image { transition: transform var(--t-standard) var(--ease-out); }
.product-card__media:hover .product-card__image { transform: scale(1.03); }

.product-card__info { padding-top: 16px; }
.product-card__name {
  font-family: var(--font-display);
  font-weight: 500;
  font-size: 26px;
  cursor: pointer;
  margin-bottom: 6px;
}
.product-card__desc {
  font-size: var(--fs-body-s);
  opacity: 0.65;
  margin-bottom: 16px;
  max-width: 32ch;
}
.product-card__footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.product-card__price {
  font-family: var(--font-ui);
  font-weight: 600;
  font-size: var(--fs-body-m);
}

/* ------------------------------------------------------------ detail overlay */

.detail-overlay {
  position: fixed;
  inset: 0;
  z-index: 60;
  display: flex;
  align-items: center;
  justify-content: center;
}
.detail-overlay__scrim {
  position: absolute;
  inset: 0;
  background: rgba(23, 23, 23, 0.42);
  animation: fadeIn var(--t-standard) var(--ease-out);
}
@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }

.detail {
  position: relative;
  width: min(1040px, 92vw);
  max-height: 88vh;
  background: var(--white);
  border-radius: var(--radius-l);
  overflow: hidden;
  display: grid;
  grid-template-columns: 1.1fr 1fr;
}
@media (max-width: 767px) {
  .detail {
    width: 100vw;
    height: 100vh;
    max-height: 100vh;
    border-radius: 0;
    grid-template-columns: 1fr;
    grid-template-rows: auto 1fr;
    overflow-y: auto;
  }
}

.detail__close {
  position: absolute;
  top: 20px;
  right: 20px;
  z-index: 2;
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background: rgba(248, 248, 246, 0.85);
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.detail__media {
  position: relative;
  aspect-ratio: 4 / 5;
}
@media (max-width: 767px) { .detail__media { aspect-ratio: 4 / 3.6; } }
.detail__image { position: absolute; inset: 0; }

.detail__body {
  padding: 56px 48px;
  display: flex;
  flex-direction: column;
  overflow-y: auto;
}
@media (max-width: 1023px) { .detail__body { padding: 40px 32px; } }
@media (max-width: 767px) { .detail__body { padding: 32px 24px 40px; } }

.detail__back { margin-bottom: 24px; align-self: flex-start; }

.detail__tag { position: static; display: inline-block; margin-bottom: 16px; }

.detail__name {
  font-family: var(--font-display);
  font-weight: 500;
  font-size: var(--fs-display-m);
  line-height: 1.02;
  margin-bottom: 16px;

  opacity: 0;
  transform: translateY(14px);
  transition: opacity var(--t-standard) var(--ease-out), transform var(--t-standard) var(--ease-out);
}
.detail__desc {
  font-size: var(--fs-body-l);
  opacity: 0;
  max-width: 42ch;
  margin-bottom: 32px;
  transform: translateY(14px);
  transition: opacity var(--t-standard) var(--ease-out) 60ms, transform var(--t-standard) var(--ease-out) 60ms;
}
.detail__row {
  display: flex;
  align-items: center;
  gap: 20px;
  margin-bottom: 32px;
  opacity: 0;
  transform: translateY(14px);
  transition: opacity var(--t-standard) var(--ease-out) 120ms, transform var(--t-standard) var(--ease-out) 120ms;
}
.detail__price { font-size: var(--fs-h-s); font-weight: 600; }
.detail__actions {
  display: flex;
  align-items: center;
  gap: 24px;
  margin-top: auto;
  opacity: 0;
  transform: translateY(14px);
  transition: opacity var(--t-standard) var(--ease-out) 180ms, transform var(--t-standard) var(--ease-out) 180ms;
}
.detail__add { flex: 1; justify-content: center; }
.detail__in-bag {
  margin-top: 16px;
  font-size: var(--fs-label-l);
  opacity: 0;
  color: var(--olive);
  transition: opacity var(--t-standard) var(--ease-out) 220ms;
}

.detail__body--revealed .detail__name,
.detail__body--revealed .detail__desc,
.detail__body--revealed .detail__row,
.detail__body--revealed .detail__actions,
.detail__body--revealed .detail__in-bag {
  opacity: 1;
  transform: translateY(0);
}

/* -------------------------------------------------------------------- cart */

.cart-overlay {
  position: fixed;
  inset: 0;
  z-index: 60;
  visibility: hidden;
  pointer-events: none;
}
.cart-overlay--open { visibility: visible; pointer-events: auto; }

.cart-overlay__scrim {
  position: absolute;
  inset: 0;
  background: rgba(23, 23, 23, 0.42);
  opacity: 0;
  transition: opacity var(--t-standard) var(--ease-out);
}
.cart-overlay--open .cart-overlay__scrim { opacity: 1; }

.cart {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  width: min(440px, 100vw);
  background: var(--white);
  display: flex;
  flex-direction: column;
  padding: 40px 32px;
  transform: translateX(100%);
  transition: transform var(--t-standard) var(--ease-out);
}
.cart--open { transform: translateX(0); }
.cart--reduced { transition: none; }

.cart__header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  margin-bottom: 40px;
}
.cart__title {
  font-family: var(--font-display);
  font-weight: 500;
  font-size: var(--fs-h-l);
  line-height: 0.98;
}
.cart__close {
  width: 34px;
  height: 34px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.cart__empty {
  display: flex;
  flex-direction: column;
  gap: 16px;
  margin-top: 24px;
}
.cart__empty p { opacity: 0.7; }

.cart__scroll {
  flex: 1;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 32px;
}

.cart__list {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.cart-item { display: flex; align-items: center; gap: 16px; }
.cart-item__thumb {
  width: 64px;
  height: 64px;
  border-radius: var(--radius-m);
  flex-shrink: 0;
}
.cart-item__info { flex: 1; min-width: 0; }
.cart-item__name { font-weight: 500; font-size: var(--fs-body-m); margin-bottom: 2px; }
.cart-item__price { font-size: var(--fs-body-s); opacity: 0.6; }

.cart__section-label {
  font-size: var(--fs-label-l);
  font-weight: 600;
  letter-spacing: 0.04em;
  opacity: 0.55;
  margin-bottom: 16px;
}

/* receiving method */
.receiving { border-top: 1px solid rgba(23, 23, 23, 0.08); padding-top: 24px; }
.receiving__option {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  width: 100%;
  text-align: left;
  padding: 14px;
  border: 1px solid rgba(23, 23, 23, 0.14);
  border-radius: var(--radius-m);
  margin-bottom: 12px;
  transition: border-color var(--t-micro) var(--ease-out);
}
.receiving__option:last-child { margin-bottom: 0; }
.receiving__option--active { border-color: var(--black); }
.receiving__radio {
  flex-shrink: 0;
  margin-top: 3px;
  width: 16px;
  height: 16px;
  border-radius: 50%;
  border: 1px solid rgba(23, 23, 23, 0.3);
  position: relative;
}
.receiving__option--active .receiving__radio { border-color: var(--black); }
.receiving__option--active .receiving__radio::after {
  content: "";
  position: absolute;
  inset: 3px;
  border-radius: 50%;
  background: var(--gold);
}
.receiving__title { display: block; font-size: var(--fs-body-m); font-weight: 500; }
.receiving__sub { display: block; font-size: var(--fs-label-s); opacity: 0.55; margin-top: 2px; }

/* pickup */
.pickup { border-top: 1px solid rgba(23, 23, 23, 0.08); padding-top: 24px; }
.pickup__address { font-size: var(--fs-body-s); opacity: 0.6; margin-bottom: 16px; }
.pickup__slots { display: flex; flex-wrap: wrap; gap: 10px; }
.pickup__slot {
  height: 38px;
  padding: 0 16px;
  border-radius: var(--radius-m);
  border: 1px solid rgba(23, 23, 23, 0.2);
  font-size: var(--fs-label-l);
  font-weight: 500;
  transition: background var(--t-micro) var(--ease-out), color var(--t-micro) var(--ease-out), border-color var(--t-micro) var(--ease-out);
}
.pickup__slot--active { background: var(--black); border-color: var(--black); color: var(--white); }

/* delivery */
.delivery { border-top: 1px solid rgba(23, 23, 23, 0.08); padding-top: 24px; }
.delivery__input {
  width: 100%;
  resize: none;
  border: 1px solid rgba(23, 23, 23, 0.2);
  border-radius: var(--radius-m);
  padding: 12px 14px;
  font-family: var(--font-ui);
  font-size: var(--fs-body-m);
  margin-bottom: 12px;
}
.delivery__input:focus { border-color: var(--black); }
.delivery__fee-note { font-size: var(--fs-label-s); opacity: 0.55; }

.cart__footer {
  padding-top: 24px;
  margin-top: 24px;
  border-top: 1px solid rgba(23, 23, 23, 0.08);
}
.cart__totals { margin-bottom: 20px; }
.cart__totals-row {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  font-size: var(--fs-body-s);
  opacity: 0.65;
  padding: 4px 0;
}
.cart__totals-row--total {
  opacity: 1;
  font-size: var(--fs-label-l);
  font-weight: 600;
  letter-spacing: 0.04em;
  margin-top: 8px;
  padding-top: 12px;
  border-top: 1px solid rgba(23, 23, 23, 0.08);
}
.cart__total-value { font-family: var(--font-display); font-size: 28px; font-weight: 500; letter-spacing: 0; }
.btn-whatsapp--disabled { opacity: 0.4; pointer-events: none; }
.cart__hint { margin-top: 10px; font-size: var(--fs-label-s); opacity: 0.6; text-align: center; }

/* ---------------------------------------------------------------- heritage */

.heritage { padding: 160px 0; background: var(--cream); }
@media (max-width: 767px) { .heritage { padding: 72px 0; } }

.heritage__grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 64px;
  align-items: center;
}
@media (max-width: 900px) {
  .heritage__grid { grid-template-columns: 1fr; gap: 40px; }
}

.heritage__year {
  font-family: var(--font-display);
  font-weight: 500;
  font-size: var(--fs-display-l);
}
.heritage__line {
  margin-top: 24px;
  font-size: var(--fs-body-l);
  max-width: 34ch;
  opacity: 0.75;
}
.heritage__media {
  aspect-ratio: 3 / 4;
  border-radius: var(--radius-l);
}
@media (max-width: 900px) { .heritage__media { order: -1; } }

/* ---------------------------------------------------------------- memorias */

.memorias { padding: 120px 0; }
@media (max-width: 767px) { .memorias { padding: 72px 0; } }
.memorias__quote {
  font-family: var(--font-display);
  font-style: italic;
  font-weight: 400;
  font-size: var(--fs-display-m);
  max-width: 16ch;
  line-height: 1.15;
}
.memorias__quote { max-width: 24ch; }
.circulo__enroll-inline { max-width: 520px; }
.location__cta { display:flex; flex-wrap:wrap; gap:16px 28px; align-items:center; }
.memorias__attr {
  display: block;
  font-family: var(--font-ui);
  font-style: normal;
  font-size: var(--fs-body-s);
  opacity: 0.55;
  margin-top: 24px;
  letter-spacing: 0.02em;
}

/* ---------------------------------------------------------------- circulo */

.circulo { padding: 120px 0 160px; background: var(--black); color: var(--white); position: relative; }

/* Círculo Home — full-screen takeover, same mechanism as the product detail
   and cart overlays: fixed, covers the whole viewport, unmissable regardless
   of scroll position. */
.circulo-home-overlay {
  position: fixed;
  inset: 0;
  z-index: 65;
}
.circulo-home-overlay__scrim {
  position: absolute;
  inset: 0;
  background: var(--black);
}
.circulo-home-overlay__panel {
  position: absolute;
  inset: 0;
  overflow-y: auto;
  padding: 96px 0 120px;
}
@media (max-width: 767px) { .circulo-home-overlay__panel { padding: 72px 0 100px; } }
@media (max-width: 767px) { .circulo { padding: 72px 0 120px; } }

.circulo__intro {
  opacity: 0;
  transform: translateY(20px);
  transition: opacity var(--t-cinematic) var(--ease-out), transform var(--t-cinematic) var(--ease-out);
}
.circulo__intro--revealed { opacity: 1; transform: translateY(0); }
.circulo__title {
  font-family: var(--font-display);
  font-weight: 500;
  font-size: var(--fs-display-l);
}
.circulo__tagline { margin-top: 16px; opacity: 0.6; font-size: var(--fs-body-l); }

/* eligibility gate */
.circulo__gate { padding-bottom: 40px; }
.circulo__gate-progress { margin-top: 16px; font-size: var(--fs-body-s); opacity: 0.5; }
.circulo__gate-headline {
  font-family: var(--font-display);
  font-weight: 500;
  font-size: var(--fs-display-l);
}
.circulo__gate-brand {
  margin-top: 12px;
  font-size: var(--fs-label-l);
  font-weight: 600;
  letter-spacing: 0.08em;
  opacity: 0.6;
}
.circulo__gate-cta { margin-top: 32px; }

/* micro-copy lead lines under section eyebrows */
.circulo__lead {
  font-family: var(--font-display);
  font-style: italic;
  font-size: var(--fs-h-s);
  margin-bottom: 24px;
  opacity: 0.92;
}

/* the quiet threshold-crossing pause (used both on entry and after enrolling) */
.circulo__threshold {
  min-height: 240px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 16px;
  cursor: pointer;
}
.circulo__threshold-line {
  font-family: var(--font-display);
  font-style: italic;
  font-weight: 400;
  font-size: var(--fs-display-m);
  opacity: 0;
  transform: translateY(12px);
  transition: opacity var(--t-cinematic) var(--ease-out), transform var(--t-cinematic) var(--ease-out);
}
.circulo__threshold-line--in { opacity: 1; transform: translateY(0); }
.circulo__threshold-line--small {
  font-size: var(--fs-body-l);
  font-style: normal;
  opacity: 0;
  max-width: 40ch;
}
.circulo__threshold-line--small.circulo__threshold-line--in { opacity: 0.7; }

/* inline enrollment (no longer a modal — part of the same room) */
.circulo__enroll-inline { max-width: 480px; }
.circulo__enroll-lead {
  font-family: var(--font-display);
  font-style: italic;
  font-size: var(--fs-h-s);
  margin-bottom: 32px;
  max-width: 24ch;
}
.enroll__form { display: flex; flex-direction: column; gap: 20px; }
.enroll__field { display: flex; flex-direction: column; gap: 8px; }
.enroll__field span {
  font-size: var(--fs-label-s);
  font-weight: 600;
  letter-spacing: 0.04em;
  opacity: 0.6;
}
.enroll__field input,
.enroll__field textarea {
  background: transparent;
  color: var(--white);
  border: 1px solid rgba(248, 248, 246, 0.25);
  border-radius: var(--radius-m);
  padding: 12px 14px;
  font-family: var(--font-ui);
  font-size: var(--fs-body-m);
  resize: none;
}
.enroll__field input::placeholder,
.enroll__field textarea::placeholder { color: rgba(248, 248, 246, 0.4); }
.enroll__field input[aria-invalid="true"] { border-color: var(--brick); }
.enroll__field-error { font-size: var(--fs-label-s); color: var(--brick); }
.enroll__field input:focus,
.enroll__field textarea:focus { border-color: var(--white); }
.enroll__submit { justify-content: center; margin-top: 8px; }

/* O que fica */
.circulo__memory { border-top: 1px solid rgba(248, 248, 246, 0.12); padding-top: 56px; }
.circulo__memory-line {
  font-family: var(--font-display);
  font-style: italic;
  font-size: var(--fs-h-s);
  max-width: 38ch;
  opacity: 0.92;
  margin-bottom: 16px;
}
.circulo__memory-anchor { font-size: var(--fs-label-s); opacity: 0.5; letter-spacing: 0.03em; }
.circulo__voltar { padding-top: 8px; }

.circulo__layout {
  display: flex;
  flex-direction: column;
  gap: 96px;
  margin-top: 80px;
}
@media (max-width: 767px) { .circulo__layout { gap: 64px; margin-top: 56px; } }

.circulo__eyebrow {
  font-size: var(--fs-label-l);
  font-weight: 600;
  letter-spacing: 0.06em;
  opacity: 0.55;
  margin-bottom: 20px;
}

/* favorite */
.circulo__favorite-grid {
  display: grid;
  grid-template-columns: 1.05fr 0.95fr;
  gap: 64px;
  align-items: center;
}
@media (max-width: 900px) {
  .circulo__favorite-grid { grid-template-columns: 1fr; gap: 32px; }
}
.circulo__favorite-media {
  aspect-ratio: 4 / 5;
  border-radius: var(--radius-l);
  overflow: hidden;
  cursor: pointer;
}
.circulo__favorite-name {
  font-family: var(--font-display);
  font-weight: 500;
  font-size: var(--fs-display-m);
  margin-bottom: 16px;
}
.circulo__favorite-desc { opacity: 0.65; max-width: 34ch; margin-bottom: 24px; font-size: var(--fs-body-l); }
.circulo__favorite-price {
  display: block;
  font-size: var(--fs-h-s);
  font-weight: 600;
  margin-bottom: 32px;
}
.circulo__favorite--empty { max-width: 44ch; }
.circulo__empty-title {
  font-family: var(--font-display);
  font-weight: 500;
  font-size: var(--fs-h-l);
  margin-bottom: 12px;
}
.circulo__empty-title--s { font-size: var(--fs-h-m); }
.circulo__empty-line { opacity: 0.6; margin-bottom: 24px; }
.circulo .editorial-link { color: var(--white); }

/* duo: recent orders + benefits, side by side on desktop */
.circulo__duo {
  display: grid;
  grid-template-columns: 1.2fr 0.8fr;
  gap: 64px;
}
@media (max-width: 900px) {
  .circulo__duo { grid-template-columns: 1fr; gap: 56px; }
}

.recent-orders-list { display: flex; flex-direction: column; }
.recent-order {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  gap: 24px;
  padding: 20px 0;
  border-top: 1px solid rgba(248, 248, 246, 0.12);
}
.recent-orders-list .recent-order:last-child { border-bottom: 1px solid rgba(248, 248, 246, 0.12); }
.recent-order__date { font-size: var(--fs-label-s); opacity: 0.5; margin-bottom: 6px; letter-spacing: 0.03em; }
.recent-order__items { font-size: var(--fs-body-m); margin-bottom: 4px; }
.recent-order__price { font-size: var(--fs-body-s); opacity: 0.55; }
.recent-order__confirm { display: flex; flex-direction: column; align-items: flex-end; gap: 8px; }
.recent-order__confirm-label {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: var(--fs-label-s);
  font-weight: 600;
  letter-spacing: 0.04em;
  color: var(--gold);
  white-space: nowrap;
}

/* meus mimos */
.mimos__balance-row { display: flex; align-items: baseline; gap: 8px; margin-bottom: 12px; }
.mimos__balance { font-family: var(--font-ui); font-weight: 600; font-size: var(--fs-h-m); }
.mimos__balance-label { font-size: var(--fs-label-l); opacity: 0.6; letter-spacing: 0.03em; }
.mimos__line { font-size: var(--fs-body-s); opacity: 0.6; max-width: 34ch; margin-bottom: 28px; }

.mimos-badge {
  display: inline-block;
  background: var(--cream);
  color: var(--black);
  font-size: 10px;
  font-weight: 600;
  letter-spacing: 0.05em;
  padding: 4px 8px;
  border-radius: var(--radius-s);
  margin-bottom: 6px;
}

.mimos-list { display: flex; flex-direction: column; }
.mimos-reward {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  gap: 16px;
  padding: 16px 0;
  border-top: 1px solid rgba(248, 248, 246, 0.12);
}
.mimos-list .mimos-reward:last-child { border-bottom: 1px solid rgba(248, 248, 246, 0.12); }
.mimos-reward__name { font-size: var(--fs-body-m); margin-bottom: 2px; }
.mimos-reward__cost { font-size: var(--fs-label-s); opacity: 0.55; letter-spacing: 0.03em; }
.mimos-reward__locked { font-size: var(--fs-label-s); opacity: 0.4; white-space: nowrap; }
.mimos-reward__confirm { display: flex; flex-direction: column; align-items: flex-end; gap: 8px; }
.mimos-reward__confirm-label {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: var(--fs-label-s);
  font-weight: 600;
  letter-spacing: 0.04em;
  color: var(--gold);
  white-space: nowrap;
}
.mimos-reward__confirm-actions { display: flex; gap: 16px; }

/* surprise */
.circulo__surprise { border-top: 1px solid rgba(248, 248, 246, 0.12); padding-top: 56px; }
.surprise-trigger {
  display: inline-flex;
  align-items: center;
  gap: 12px;
  font-family: var(--font-display);
  font-style: italic;
  font-size: var(--fs-h-s);
  color: var(--white);
  cursor: pointer;
  opacity: 0.85;
  transition: opacity var(--t-micro) var(--ease-out);
}
.surprise-trigger:hover { opacity: 1; }
.surprise-content {
  display: flex;
  flex-direction: column;
  gap: 12px;
  animation: surpriseIn var(--t-cinematic) var(--ease-out) both;
}
@keyframes surpriseIn {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}
.surprise-badge { align-self: flex-start; }
.surprise-message {
  font-family: var(--font-display);
  font-style: italic;
  font-size: var(--fs-h-s);
  max-width: 36ch;
}
.surprise-bonus { font-size: var(--fs-label-l); opacity: 0.55; }

/* --------------------------------------------------------------- location */

.location { padding: 120px 0; background: var(--cream); }
@media (max-width: 767px) { .location { padding: 72px 0; } }

.location__grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 64px;
  align-items: start;
}
@media (max-width: 900px) {
  .location__grid { grid-template-columns: 1fr; gap: 32px; }
}

.location__eyebrow { color: var(--black); margin-bottom: 20px; }
.location__name {
  font-family: var(--font-display);
  font-weight: 500;
  font-size: var(--fs-display-m);
  margin-bottom: 12px;
}
.location__address { font-size: var(--fs-body-l); opacity: 0.7; max-width: 36ch; margin-bottom: 16px; }

.location__status {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  font-size: var(--fs-label-s);
  font-weight: 600;
  letter-spacing: 0.05em;
  margin-bottom: 32px;
}
.location__status::before {
  content: "";
  width: 7px;
  height: 7px;
  border-radius: 50%;
}
.location__status--open { color: var(--olive); }
.location__status--open::before { background: var(--olive); }
.location__status--closed { color: var(--brick); }
.location__status--closed::before { background: var(--brick); }

.location__hours { margin-bottom: 32px; max-width: 36ch; }
.location__hours-row {
  display: flex;
  justify-content: space-between;
  padding: 10px 0;
  border-top: 1px solid rgba(23, 23, 23, 0.1);
  font-size: var(--fs-body-s);
  opacity: 0.8;
}
.location__hours-row:last-child { border-bottom: 1px solid rgba(23, 23, 23, 0.1); }

.location__phone {
  display: inline-block;
  font-size: var(--fs-body-m);
  font-weight: 500;
  margin-bottom: 32px;
  text-decoration: underline;
  text-underline-offset: 3px;
}

.location__map {
  border-radius: var(--radius-l);
  overflow: hidden;
  aspect-ratio: 4 / 3;
  background: var(--black);
}
.location__map iframe { width: 100%; height: 100%; border: 0; display: block; }

/* ------------------------------------------------------------------ footer */

.footer { padding: 48px 0; }
.footer__inner {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 12px;
}
.footer__logo { font-family: var(--font-display); font-size: 20px; }
.footer__meta { font-size: var(--fs-body-s); opacity: 0.5; }

/* -------------------------------------------------------- reduced motion */

@media (prefers-reduced-motion: reduce) {
  .lele-root * {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
  }
}
`;
